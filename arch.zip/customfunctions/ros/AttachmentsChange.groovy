package customfunctions

import com.sas.oprisk.framework.server.objects.BusinessObjectList
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.Attachment
import com.sas.oprisk.server.AttachmentContainer
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import com.sas.solutions.cpb.runtime.UIContext
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

import java.sql.Timestamp

/**
 * Created by Nikolay Litvyak (SAS Russia) on 20.07.2016.
 */
class AttachmentsChange extends Function {
    private static Log log = LogFactory.getLog(AttachmentsChange.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        Integer groupNo = (Integer) args[0]
        String param = ((String) args[1]).toUpperCase().trim()
        if (groupNo == null || param == null)
            throw new EvaluationException(new IllegalArgumentException())
        PersistenceSession psession = ServiceLocator.getPersistenceSession();
        UIContext context = getContext();

        AttachmentContainer object = (AttachmentContainer) context.getValue("BUSINESSOBJECT")
        BusinessObjectList<Attachment> unsortedAttachments = object.getAttachments(psession)
        Map<Integer, ArrayList<Attachment>> attachments = getAttachmentsMap(unsortedAttachments)

        if (!attachments.containsKey(groupNo))
            return null
        if (param == "SIZE") {
            return attachments.get(groupNo).size()
        }
        if (param == "LAST_ADDED") {
            return getDateOfLastAttachment(attachments.get(groupNo))
        }
        return null
    }

    HashMap<Integer, ArrayList<Attachment>> getAttachmentsMap(List<Attachment> attachments) {
        Map<Integer, ArrayList<Attachment>> attachmentMap = new HashMap<Integer, ArrayList<Attachment>>()
        for (Attachment attachment : attachments) {
            Integer groupNo = attachment.getGroupNo()
            if (attachmentMap.get(groupNo) == null)
                attachmentMap.put(groupNo, new ArrayList<Attachment>())
            attachmentMap.get(groupNo).add(attachment)
        }
        return attachmentMap
    }

    Timestamp getDateOfLastAttachment(List<Attachment> attachments) {

        Timestamp max = null
        for (Attachment attachment : attachments) {
            Timestamp creationTS = attachment.getValidFrom()
            if (creationTS == null)
                creationTS = new Timestamp(new Date().getTime())
            if (max == null || max.before(creationTS))
                max = creationTS
        }
        return max
        /*
        Date truncatedMax = DateUtils.truncate(new Date(max.getTime()), Calendar.DATE)
        return truncatedMax
        */
    }

    @Override
    int getArgumentCount() {
        return 0
    }
}

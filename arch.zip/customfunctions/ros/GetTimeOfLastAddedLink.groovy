package customfunctions

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.LinkInstance
import com.sas.oprisk.server.LinkType
import com.sas.oprisk.server.logical.LinkInstanceContainer
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

import java.sql.Timestamp

/**
 * Created by Nikolay Litvyak (SAS Russia) on 26.07.2016.
 */
class GetTimeOfLastAddedLink extends Function{
    private static Log log = LogFactory.getLog(GetTimeOfLastAddedLink.class)
    @Override
    Object evaluate(Object[] args) throws EvaluationException {

        String linkTypeNm = (String) args[0]
        String sourceSystemCd = (String) args[1]
        LinkInstanceContainer container = (LinkInstanceContainer) args[2]
        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        LinkType linkType = LinkType.object.fetchIfExistsByExternalReference(sourceSystemCd,linkTypeNm,psession)
        if(linkType==null)
            return null
        Map<Long,LinkInstance> linkInstanceMap = container.getLinkInstanceMap(linkType.getLinkTypeRk())
        return getDateOfLastLinkInstance(linkInstanceMap.values())
    }

    @Override
    int getArgumentCount() {
        return 0
    }

    Timestamp getDateOfLastLinkInstance(Collection<LinkInstance> attachments) {

        Timestamp max = null
        for (LinkInstance attachment : attachments) {
            Timestamp creationTS = attachment.getValidFrom()
            if (creationTS == null)
                creationTS = new Timestamp(new Date().getTime())
            if (max == null || max.before(creationTS))
                max = creationTS
        }
        return max
    }
}

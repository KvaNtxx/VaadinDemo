package customfunctions

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.DimensionNode
import com.sas.oprisk.server.logical.DimensionalAreaHandle
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

/**
 * Created by Nikolay Litvyak (SAS Russia) on 24.02.2016.
 */
class HowManyNodesOfDimensionInLocation extends Function{
    private static Log log = LogFactory.getLog(HowManyNodesOfDimensionInLocation.class);

    @Override
    Object evaluate(Object[] args) throws EvaluationException {

        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        DimensionalAreaHandle location = (DimensionalAreaHandle) args[0]
        String dimensionName = (String) args[1]
        if(location == null || dimensionName == null)
            return 0
        List<DimensionNode> dimensionalNodes = location.fetch(psession).getNodes(psession).toList()
        List<DimensionNode> dimNodes = getDimensionNodesByDimension(dimensionalNodes, dimensionName)

        return dimNodes.size()
    }

    private List<DimensionNode> getDimensionNodesByDimension(List<DimensionNode> dimensionalPoints, String dimension) {
        List<DimensionNode> targetDimensionalPoints = new ArrayList<DimensionNode>()
        for (DimensionNode node : dimensionalPoints) {
            if (node.getDimension().getSqlName() == dimension)
                targetDimensionalPoints.add(node)
        }
        return targetDimensionalPoints
    }

    @Override
    int getArgumentCount() {
        return 2
    }
}
/*
<function name="C_HowManyNodesOfDimensionInLocation" qualified-class-name="customfunctions.HowManyNodesOfDimensionInLocation"/>

        <validation test="C_HowManyNodesOfDimensionInLocation(location,'MANAGEMENT_ORG') < 2" >
               <errmsg> Нельзя выбирать более одной ОргСтруктуры </errmsg>
        </validation>
C_HowManyNodesOfDimensionInLocation(location,'MANAGEMENT_ORG')
 */
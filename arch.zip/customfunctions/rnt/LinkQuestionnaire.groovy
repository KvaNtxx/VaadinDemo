package customfunctions

import com.sas.oprisk.framework.server.objects.BusinessObjectList
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.framework.server.query.Query
import com.sas.oprisk.framework.server.query.QueryConstraint
import com.sas.oprisk.monitor.web.AppRequestContext
import com.sas.oprisk.monitor.web.AppRequestContextHolder
import com.sas.oprisk.monitor.web.MonitorSession
import com.sas.oprisk.server.CustomObject1
import com.sas.oprisk.server.LinkInstance
import com.sas.oprisk.server.LinkType
import com.sas.oprisk.server.User
import com.sas.oprisk.server.base.CustomObject1Query
import com.sas.oprisk.server.base.CustomObject1QueryVariable
import com.sas.oprisk.server.behavior.PrimaryBusinessObject
import com.sas.oprisk.server.cpb.expr.function.CreateLinkInstance
import com.sas.oprisk.server.logical.LinkInstanceContainer
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.oprisk.server.web.cpb.runtime.MonitorUIContext
import com.sas.solutions.cpb.docs.*
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
/**
 * Created by Nikolay Litvyak (SAS Russia) on 11.03.2016.
 */

@FunctionDescription("Функция создания анкет для оценки Проверки ВА и её участников.")
@FunctionReturnType("Boolean")
@FunctionReturnDescription("True - если функция отработала успешно, False - если нет.")
@FunctionArguments([
        @FunctionArgument(name = "auditors", type = "List<User>", description = "Список участников проверки для оценки которых необходимо создать анкеты"),
        @FunctionArgument(name = "businessObject", type = "PrimaryBusinessObject", description = "Аудит для которого необходимо создать анкеты"),
        @FunctionArgument(name = "container", type = "LinkInstanceContainer", description = "Ссылка на контейнер экземпляров связи (LinkInstance)")
])
@FunctionExamples([
        @FunctionExample(code = "<set name=\"TEMP.C_LinkQuestionnaire\" value=\"C_LinkQuestionnaire(auditors,businessObject,linkedBusinessObjects)\"/>"),
])
class LinkQuestionnaire extends Function {

    private static Log log = LogFactory.getLog(LinkQuestionnaire.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {

        if (args[0] == null || args[1] == null || args[2] == null)
            return false
        //(auditors,businessObject,linkedBusinessObjects)
        LinkQuestionnaireImpl impl = new LinkQuestionnaireImpl()
        return impl.evaluate(args)
    }

    @Override
    int getArgumentCount() {
        return 3
    }
}



class LinkQuestionnaireImpl {

    private static Log log = LogFactory.getLog(LinkQuestionnaireImpl.class)
    private final String FIELD_PARTICIPANT_NAME_PATTERN = "x_aud_auditor_"
    private final String FIELD_PARTICIPANT_ID_PATTERN = "x_aud_auditor_id_"
    private final String LINK_INSTANCE_USER_FIELD_NAME = "x_li_co1_usernm"
    private final String LINK_INSTANCE_USER_ID_FIELD_NAME = "x_li_co1_userid"
    private final int MAX_AUDITORS = 40
    private final String CO1_PREFIX = "QU-"
    private final String CO1_IS_ACTIVE_FIELD_NAME = "x_co1_aud_active"
    private final String CO1_AUDIT_FLG_FIELD = "x_co1_auditflg"
    private final String CO1_TYPE_FIELD_NAME = "x_co1_aud_type"
    private final String CO1_TYPE_QUALITY = "quality"
    private final String CO1_TYPE_PARTICIPANT = "participant"
    private final String LINK_TYPE_SOURCE_SYSTEM_CD = "MON"
    private final String LINK_TYPE_CO1 = "x_audit_x_co1"
    private final String LINK_TYPE_PARTICIPANT_ID_PATTERN = "x_audit_x_co1_auditor_"

    private PrimaryBusinessObject hostBusinessObject
    private LinkInstanceContainer container
    private List<CustomObject1> allQuestions
    private List<User> auditors

    private AppRequestContext appCtx
    private MonitorSession msession
    private MonitorUIContext srcCtx

    Object evaluate(Object[] args) throws EvaluationException {

        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        if (args[0] == null || args[1] == null || args[2] == null)
            return false
        //(auditors,businessObject,linkedBusinessObjects)

        appCtx = AppRequestContextHolder.getRequestContext()
        msession = appCtx.getSessionContext()
        srcCtx = msession.getCachedContext("Audit")

        auditors = (List<User>) args[0]
        hostBusinessObject = (PrimaryBusinessObject) args[1]
        container = (LinkInstanceContainer) args[2]
        trimAuditors()
        selectAllQuestions(psession)
        linkQualityQuestionnaire(psession)
        if (!isParticipantLinkTypesValid(psession))
            return false
        linkMultiplyParticipantsQuestionnaire(psession)
        return true
    }

    private void trimAuditors() {
        List<User> trimmedAuditors = new BusinessObjectList<User>()
        for (int i = 0; i < MAX_AUDITORS && i < auditors.size(); i++)
            trimmedAuditors.add(auditors.get(i))
        trimmedAuditors.sort(User.object.getUserIdComparator())
        auditors = trimmedAuditors
    }

    private void selectAllQuestions(PersistenceSession psession) {
        /*
        BusinessObjectList<CustomObject1> allCustomObject1 = CustomObject1.ALL.execute(psession)
        allQuestions = new BusinessObjectList<CustomObject1>()
        for (CustomObject1 co1_all : allCustomObject1) {
            if (co1_all.getCustObj1Id().startsWith(CO1_PREFIX))
                allQuestions.add(co1_all)
        */
        CustomObject1Query query = CustomObject1.ALL
        CustomObject1QueryVariable co1QV = query.result()
        List<QueryConstraint> constraints = new ArrayList<QueryConstraint>()
        constraints.add(Query.like(co1QV.custObj1Id, CO1_PREFIX + '%'))
//        log.warn("DEBUG SQL=" + DynamicSqlFormatter.format((SqlPersistenceStrategy) (psession.getStrategy()), ObjectToSqlTransformer.transform(query.withConstraints(constraints).baseQuery.asObjectQuery()), new HashMap<String, FilledHole>(0)))
        allQuestions = query.withConstraints(constraints).execute(psession)
    }

    private void linkQualityQuestionnaire(PersistenceSession psession) {

        BusinessObjectList<CustomObject1> qualityQuestion = new BusinessObjectList<CustomObject1>()
        if (!isContainerValid(LINK_TYPE_SOURCE_SYSTEM_CD, LINK_TYPE_CO1, container, psession))
            return

        for (CustomObject1 question : allQuestions) {
            if (question.getCustBooleanFieldValue(CO1_IS_ACTIVE_FIELD_NAME, psession) && question.getCustBooleanFieldValue(CO1_AUDIT_FLG_FIELD, psession)
                    && question.getCustSingleOptionFieldValue(CO1_TYPE_FIELD_NAME, psession) == CO1_TYPE_QUALITY)
                qualityQuestion.add(question)
        }
        createLinks(LINK_TYPE_SOURCE_SYSTEM_CD, LINK_TYPE_CO1, hostBusinessObject, qualityQuestion, container)
    }

    private void linkMultiplyParticipantsQuestionnaire(PersistenceSession psession) {
        BusinessObjectList<CustomObject1> participantQuestion = new BusinessObjectList<CustomObject1>()
        for (CustomObject1 question : allQuestions) {
            if (question.getCustBooleanFieldValue(CO1_IS_ACTIVE_FIELD_NAME, psession) && question.getCustBooleanFieldValue(CO1_AUDIT_FLG_FIELD, psession)
                    && question.getCustSingleOptionFieldValue(CO1_TYPE_FIELD_NAME, psession) == CO1_TYPE_PARTICIPANT)
                participantQuestion.add(question)
        }
        int i = 1

        for (User auditor : auditors) {
            linkSingleParticipantQuestionnaire(LINK_TYPE_PARTICIPANT_ID_PATTERN + i, participantQuestion, auditor, psession)
            srcCtx.setValue(FIELD_PARTICIPANT_NAME_PATTERN + i,auditor.getDisplayNm())
            srcCtx.setValue(FIELD_PARTICIPANT_ID_PATTERN + i,auditor.getUserId())
            i++;
        }
    }

    private void linkSingleParticipantQuestionnaire(String linkTypeParticipantId, BusinessObjectList<CustomObject1> participantQuestion, User auditor, PersistenceSession psession) {
        createLinksWithFields(LINK_TYPE_SOURCE_SYSTEM_CD, linkTypeParticipantId, hostBusinessObject, participantQuestion, container, auditor.getDisplayNm(), auditor.getUserId(), psession)
    }

    private void createLinks(String linkTypeSourceSystemCd, String linkTypeId, PrimaryBusinessObject hostBusinessObject, List<PrimaryBusinessObject> objectList, LinkInstanceContainer container) {
        CreateLinkInstance creator = new CreateLinkInstance()
        for (PrimaryBusinessObject object : objectList) {
            creator.evaluate(linkTypeSourceSystemCd, linkTypeId, hostBusinessObject, object.getTaggedPointerHandle().toString(), container)
        }
    }

    private void createLinksWithFields(String linkTypeSourceSystemCd, String linkTypeId, PrimaryBusinessObject hostBusinessObject, List<PrimaryBusinessObject> objectList, LinkInstanceContainer container, String userName, String userId, PersistenceSession psession) {
        CreateLinkInstance creator = new CreateLinkInstance()
        for (PrimaryBusinessObject object : objectList) {
            LinkInstance linkInstance = (LinkInstance) creator.evaluate(linkTypeSourceSystemCd, linkTypeId, hostBusinessObject, object.getTaggedPointerHandle().toString(), container)
            linkInstance.setCustStringFieldValue(LINK_INSTANCE_USER_FIELD_NAME, userName, psession)
            linkInstance.setCustStringFieldValue(LINK_INSTANCE_USER_ID_FIELD_NAME, userId, psession)
        }
    }
/*
Функция проверяет все линктайпы созданные для оценки участника проверки на валидность.
 */

    private boolean isParticipantLinkTypesValid(PersistenceSession psession) {
        boolean res = true;
        for (int i = 1; i <= MAX_AUDITORS; i++) {
            if (!isContainerValid(LINK_TYPE_SOURCE_SYSTEM_CD, LINK_TYPE_PARTICIPANT_ID_PATTERN + i, container, psession))
                return false
        }
        return res
    }
/*
Валидным считается существующий и пустой линктайп.
 */

    private boolean isContainerValid(String linkTypeSourceSystemCd, String linkTypeId, LinkInstanceContainer container, PersistenceSession psession) {
        LinkType linkType = LinkType.object.fetchIfExistsByExternalReference(linkTypeSourceSystemCd, linkTypeId, psession)
        if (linkType == null)
            return false
        Map<Long, LinkInstance> existingLinks = container.getLinkInstanceMap(linkType.getLinkTypeRk())
        if (existingLinks.size() > 0)
            return false
        return true
    }

    int getArgumentCount() {
        return 3
    }
}

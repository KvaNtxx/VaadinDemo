package customfunctions.rnt

import com.sas.oprisk.framework.server.objects.BusinessObjectList
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import com.sas.solutions.cpb.util.LabelValueColor
import org.apache.struts.util.LabelValueBean

/**
 * Created by Nikolay Litvyak (SAS Russia) on 28.10.2016.
 */
class ClearPrefixFromValueLabels extends Function{

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        BusinessObjectList<LabelValueColor> originalResponses = (BusinessObjectList<LabelValueColor>) args[0]

        for(LabelValueColor labelValueColor:  originalResponses)
        {
            labelValueColor.setLabel(labelValueColor.getColor() + "_" + labelValueColor.getLabel())
        }
        return originalResponses
    }

    @Override
    int getArgumentCount() {
        return 0
    }
}

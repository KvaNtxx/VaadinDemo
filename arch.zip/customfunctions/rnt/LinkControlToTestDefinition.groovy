package customfunctions

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.ControlInstance
import com.sas.oprisk.server.TestDefinition
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

/**
 * Created by Nikolay Litvyak (SAS Russia) on 16.02.2016.
 */

class LinkControlToTestDefinition extends Function {
    private static Log log = LogFactory.getLog(LinkControlToTestDefinition.class)
    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        if (args[0] == null || args[1] == null || args[2] == null)
            return false
        PersistenceSession psession = ServiceLocator.getPersistenceSession();
        TestDefinition testDefinition = (TestDefinition) args[0]
        String controlSourceSystem = (String) args[1]
        String controlId = (String) args[2]

        if (testDefinition.getControls(psession).size() > 0)
            return false
        ControlInstance controlInstance = ControlInstance.object.fetchIfExistsByExternalReference(controlSourceSystem, controlId, psession)
        if (controlInstance == null)
            return false
        testDefinition.addToTestExecutionContexts(controlInstance, psession)
        return true
    }

    @Override
    int getArgumentCount() {
        return 3
    }
}

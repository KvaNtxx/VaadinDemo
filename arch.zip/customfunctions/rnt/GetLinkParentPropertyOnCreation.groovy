package customfunctions

/**
 * Created by Nikolay Litvyak (SAS Russia) on 24.12.2015.
 */
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.monitor.web.AppRequestContext
import com.sas.oprisk.monitor.web.AppRequestContextHolder
import com.sas.oprisk.monitor.web.MonitorSession
import com.sas.oprisk.monitor.web.linking.CreateAndLinkForm
import com.sas.oprisk.monitor.web.utils.Breadcrumb
import com.sas.oprisk.server.LinkType
import com.sas.oprisk.server.User
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.oprisk.server.web.cpb.runtime.MonitorUIContext
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
import org.apache.struts.action.ActionForm


class GetLinkParentPropertyOnCreation extends Function{

    private static Log log = LogFactory.getLog(GetLinkParentPropertyOnCreation.class);
    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        if(args[0]==null || !(args[0] instanceof String))
            return null
        String propertyName = (String) args[0]
//      PersistenceSession psession = ServiceLocator.getPersistenceSession();
        final AppRequestContext appCtx = AppRequestContextHolder.getRequestContext();
        final MonitorSession msession = appCtx.getSessionContext();

        final Breadcrumb breadcrumb = msession.peekBreadcrumb();
        if (breadcrumb == null)
            return null;

        final ActionForm form = breadcrumb.getForm();
        final MonitorUIContext srcCtx;
        if (form instanceof CreateAndLinkForm) {
            if(propertyName=="LINKTYPE")
            {
                return getLinkTypeId(form.getLinkTypeRk())
            }
            final String uiContextId = ((CreateAndLinkForm)form).getUiContextId();
            srcCtx = msession.getCachedContextById(uiContextId);
        } else
            srcCtx = null;

        if (srcCtx != null) {
            Object parentPropertyObject = srcCtx.getValue(propertyName);
            if(parentPropertyObject == null)
                return null
            if(parentPropertyObject instanceof User)
                return ((User)parentPropertyObject).getTaggedPointerHandle().toString()
            if(parentPropertyObject instanceof Date)
                return parentPropertyObject
            return parentPropertyObject.toString()
        }

        return null
    }

    @Override
    int getArgumentCount() {
        return 1
    }

    String getLinkTypeId(long linkTypeRk)
    {
        PersistenceSession psession = ServiceLocator.getPersistenceSession();
        LinkType linkType = LinkType.object.fetch(linkTypeRk,psession)
        return  linkType.getLinkTypeId()
    }
}

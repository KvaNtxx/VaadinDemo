package customfunctions

/**
 * Created by Nikolay Litvyak (SAS Russia) on 26.04.2016.
 */

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.User
import com.sas.oprisk.server.services.ServiceLocator
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import com.sas.solutions.cpb.docs.*

@FunctionDescription("Function fetch User object for specified userId (login)")
@FunctionReturnType("User")
@FunctionReturnDescription("Fetched User or null if User can't be found")
@FunctionArguments([
        @FunctionArgument(name = "userId", type = "String", description = "userId of User object to return"),
])
public class GetUserById extends Function
{
    private static Log log = LogFactory.getLog(GetUserById.class);
    @Override
    public Object evaluate(Object[] args) throws EvaluationException{
        if (args[0] != null) {
            String userId = args[0].toString()
            // retrieve the PersistenceSession so that we can query the database
            PersistenceSession psession = ServiceLocator.getPersistenceSession()
            // "fetch" the user from the db by userId (returns null if not found)
            User user = User.object.fetchIfExistsByUserId(userId, psession)
            return user

        }
        return null;
    }
    @Override
    public int getArgumentCount()
    {
        return 1;
    }
}
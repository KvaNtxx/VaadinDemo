package customfunctions

import com.sas.oprisk.framework.server.objects.Handle
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.DimensionalPoint
import com.sas.oprisk.server.Role
import com.sas.oprisk.server.User
import com.sas.oprisk.server.behavior.PrimaryBusinessObject
import com.sas.oprisk.server.behavior.SudoPersistenceSessionWrapper
import com.sas.oprisk.server.logical.DimensionUtils
import com.sas.oprisk.server.logical.DimensionalArea
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.oprisk.server.workflow.WorkflowUtil
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import com.sas.solutions.cpb.runtime.UIContext
import com.sas.workflow.framework.client.Participant
import com.sas.workflow.framework.client.Task
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

/**
 * Created by Nikolay Litvyak (SAS Russia) on 12.09.2016.
 */
class GetCurrentWorkflowUsers extends Function {
    private static Log log = LogFactory.getLog(GetCurrentWorkflowUsers.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        PersistenceSession psession = new SudoPersistenceSessionWrapper(ServiceLocator.getPersistenceSession())
        PrimaryBusinessObject businessObject = (PrimaryBusinessObject) args[0]
        Task process = WorkflowUtil.getProcessInstance(businessObject)
        if (process == null)
            return Collections.EMPTY_LIST
//        Task started = WorkflowUtil.getStartedActivity(process)
        List<Task> startedActivities = WorkflowUtil.getStartedActivities(process, false)
        Set<Participant> allParticipants = new HashSet<Participant>()
        for (Task startedActivity : startedActivities) {
            allParticipants.addAll(startedActivity.getParticipants())
        }
        Set<User> users = new HashSet<User>()

        for (Participant participant : allParticipants) {
            users.addAll(getUsersFromParticipant(participant, psession))
        }
        return users.toList()
    }

    @Override
    int getArgumentCount() {
        return 0
    }

    Set<User> getUsersFromParticipant(Participant participant, PersistenceSession psession) {
        Participant.ParticipantType type = participant.getType()
        Participant.WorkflowRole role = participant.getRole()
        Set<User> allUsers = new HashSet<User>()
        if (!role.equals(Participant.WorkflowRole.POTENTIAL_OWNER))
            return Collections.EMPTY_SET
        //DEBUG
        /*
        log.warn(role.name())
        log.warn(type.name())
        log.warn(participant.getName())
        */

        String participantName = participant.getName()
        if (type == Participant.ParticipantType.USER) {
            User singleUser = User.object.fetchIfExistsByUserId(participantName, psession)
            if (singleUser == null)
                return Collections.EMPTY_SET
            allUsers.add(singleUser)
        } else if (participant.getType() == Participant.ParticipantType.ORGANIZATIONAL_ROLE) {
            Role metaRole = Role.object.fetchIfExistsByName(participantName, psession)
            if (metaRole == null)
                return Collections.EMPTY_SET
            HashSet<String> roleNames = new HashSet<String>()
            roleNames.add(metaRole.getRoleNm())
            List<User> usersFromRole = (List<User>) getUserListForLocationAndRoles("location", roleNames, psession)
            allUsers.addAll(usersFromRole)
        }

        return allUsers
    }

    public Object getUserListForLocationAndRoles(String locationFieldName, Set<String> roleNames, PersistenceSession psession) throws EvaluationException {

        UIContext context = getContext()
        DimensionalArea location = null
        Object something = context.getValue(locationFieldName)
        if (something instanceof Handle) {
            Handle roleUsersMap = (Handle) something
            location = DimensionUtils.getDimensionalAreaForHandle(roleUsersMap)
        } else if (something instanceof DimensionalPoint) {
            DimensionalPoint dimensionalPoint = (DimensionalPoint) something
            location = DimensionalArea.object.create(dimensionalPoint, psession)
        } else if (something instanceof DimensionalArea) {
            location = something
        }

        if (location == null) {
            return Collections.EMPTY_LIST
        } else {
            Map usersMap = User.object.getUsersForLocationAndRoles(location, roleNames, psession)
            HashMap userMap = new HashMap()
            Iterator usersMapIterator = usersMap.values().iterator()

            while (usersMapIterator.hasNext()) {
                List users = (List) usersMapIterator.next()
                Iterator usersListIterator = users.iterator()

                while (usersListIterator.hasNext()) {
                    User user = (User) usersListIterator.next()
                    userMap.put(user.getKey(), user)
                }
            }

            return new ArrayList(userMap.values())
        }

    }


}
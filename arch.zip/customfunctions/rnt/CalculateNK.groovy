package customfunctions

import com.sas.oprisk.framework.server.objects.BusinessObjectList
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.framework.server.query.Query
import com.sas.oprisk.monitor.web.AppRequestContext
import com.sas.oprisk.monitor.web.AppRequestContextHolder
import com.sas.oprisk.monitor.web.MonitorSession
import com.sas.oprisk.server.Audit
import com.sas.oprisk.server.LinkInstance
import com.sas.oprisk.server.LinkType
import com.sas.oprisk.server.NamedListMapping
import com.sas.oprisk.server.base.NamedListQuery
import com.sas.oprisk.server.base.NamedListQueryVariable
import com.sas.oprisk.server.logical.LinkInstanceContainer
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.oprisk.server.web.cpb.runtime.MonitorUIContext
import com.sas.solutions.cpb.docs.*
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
/**
 * Created by Nikolay Litvyak (SAS Russia) on 23.03.2016.
 */
@FunctionDescription("Функция считает Нормированный Коэффициент Проверки/Участника")
@FunctionReturnType("Double")
@FunctionReturnDescription("Нормированный коэффициент")
@FunctionArguments([
        @FunctionArgument(name = "businessObject", type = "PrimaryBusinessObject", description = "Аудит для которого производится расчет"),
        @FunctionArgument(name = "container", type = "LinkInstanceContainer", description = "Контейнер LBO"),
        @FunctionArgument(name = "type", type = "String", description = "Возможный тип расчета.'NKP' или 'NKU'"),
        @FunctionArgument(name = "num", type = "Integer", description = "Только для type = NKU. Порядковый номер участника 1-40"),
])
@FunctionExamples([
        @FunctionExample(code = "<set name=\"TEMP.nku\" value=\"c_CalculateNK(businessObject,linkedBusinessObjects,'NKU',25)\"/>"),
])

class CalculateNK extends Function {
    private static Log log = LogFactory.getLog(CalculateNK.class)

    private static final String FIELD_LI_CO1_ASSESSMENT_NAME = "x_li_co1_assessment"
    private static final String LINK_TYPE_QUALITY = "x_audit_x_co1"
    private static final String FIELD_AUDIT_QUALITY_KP_NAME = "x_aud_audit_kp"
    private static final String LINK_TYPE_PARTICIPANT_ID_PATTERN = "x_audit_x_co1_auditor_"
    private static final String FIELD_PARTICIPANT_KU_NAME_PATTERN = "x_aud_auditor_ku_"
    private static final String LINK_TYPE_SOURCE_SYSTEM_CD = "MON"


    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        AppRequestContext appCtx = AppRequestContextHolder.getRequestContext()
        MonitorSession msession = appCtx.getSessionContext()
        MonitorUIContext srcCtx = msession.getCachedContext("Audit")

        Audit audit = (Audit) args[0]
        LinkInstanceContainer container = (LinkInstanceContainer) args[1]
        String NKtype = args[2]

        if (NKtype == "NKP") {
            LinkType quality = LinkType.object.fetchIfExistsByExternalReference(LINK_TYPE_SOURCE_SYSTEM_CD, LINK_TYPE_QUALITY, psession)
            Map qualityLinks = container.getLinkInstanceMap(quality.getLinkTypeRk())
            if (qualityLinks == null || qualityLinks.size() == 0)
                return null
            Collection<LinkInstance> linkInstances = qualityLinks.values()
            Double kp = (Double) srcCtx.getValue(FIELD_AUDIT_QUALITY_KP_NAME)
            if (kp == null)
                kp = 1
            return getSum(linkInstances,psession) * kp / getMaxPossibleScore(linkInstances,psession)
        }

        if (NKtype == "NKU") {
            Integer participantNumber = (Integer) args[3]

            LinkType quality = LinkType.object.fetchIfExistsByExternalReference(LINK_TYPE_SOURCE_SYSTEM_CD, LINK_TYPE_PARTICIPANT_ID_PATTERN + participantNumber, psession)
            Map qualityLinks = container.getLinkInstanceMap(quality.getLinkTypeRk())
            if (qualityLinks == null || qualityLinks.size() == 0)
                return null
            Collection<LinkInstance> linkInstances = qualityLinks.values()
            Double ku = (Double) srcCtx.getValue(FIELD_PARTICIPANT_KU_NAME_PATTERN + participantNumber)
            if (ku == null)
                ku = 1
            return getSum(linkInstances,psession) * ku / getMaxPossibleScore(linkInstances,psession)
        }

        return null
    }

    @Override
    int getArgumentCount() {
        return 4
    }

    private Double getSum(Collection<LinkInstance> linkInstances, PersistenceSession psession) {
        Double sum = 0
        for (LinkInstance linkInstance : linkInstances) {
            String optionalSum = linkInstance.getCustSingleOptionFieldLabelValue(FIELD_LI_CO1_ASSESSMENT_NAME, Locale.getDefault(), psession)
            if (optionalSum != "")
                sum += Double.parseDouble(optionalSum)
        }
        return sum
    }

    private Double getMaxPossibleScore(Collection<LinkInstance> linkInstances,PersistenceSession psession) {

        NamedListMapping mapping = NamedListMapping.object.fetchByOptionMapping("linkInstance",FIELD_LI_CO1_ASSESSMENT_NAME,psession)
        String listNm = mapping.getListNm()

        return linkInstances.size() * getNamedListCount(listNm,psession)
    }

    private int getNamedListCount(String listNm,PersistenceSession psession)
    {
        NamedListQueryVariable selfVar = new NamedListQueryVariable("t_h_i_s");
        LinkedList constraints = new LinkedList();
        constraints.add(Query.equalTo(selfVar.listNm, listNm));
        NamedListQuery query = new NamedListQuery(selfVar, constraints);
        BusinessObjectList results = query.execute(psession);
        if(results == null)
            return  0
        return results.size()
    }
}

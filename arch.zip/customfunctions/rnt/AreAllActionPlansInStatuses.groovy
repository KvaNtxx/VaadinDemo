package customfunctions

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.ActionPlan
import com.sas.oprisk.server.LinkInstance
import com.sas.oprisk.server.LinkType
import com.sas.oprisk.server.behavior.PrimaryBusinessObject
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.docs.FunctionArgument
import com.sas.solutions.cpb.docs.FunctionArguments
import com.sas.solutions.cpb.docs.FunctionDescription
import com.sas.solutions.cpb.docs.FunctionExample
import com.sas.solutions.cpb.docs.FunctionExamples
import com.sas.solutions.cpb.docs.FunctionReturnDescription
import com.sas.solutions.cpb.docs.FunctionReturnType
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

/**
 * Created by Nikolay Litvyak (SAS Russia) on 16.12.2015.
 */

@FunctionDescription("Функция  позволяет проверить, были ли все связанные с предложением мероприятия включены в указанный список кодов статусов мероприятий. Список статусов задается через запятую.")
@FunctionReturnType("Boolean")
@FunctionReturnDescription("True - Если статусы мероприятий данного предложения без исключения входят в указаное множество или если у предложения нет связанных мероприятий. False - если не входят.")
@FunctionArguments([
        @FunctionArgument(name = "object", type = "PrimaryBusinessObject", description = "Объект(businessObject), связанные ActionPlan'ы которого проверяются на соответствие желаемым статусам.В определении linkType должен являться первым бизнесс объектом."),
        @FunctionArgument(name = "linkTypeName", type = "String", description = "Название типа связи в SourceSystem \"MON\" в котором вторым бизнесс объектом является ActionPlan."),
        @FunctionArgument(name = "statuses", type = "String", description = "Список проверяемых статусов через запятую."),
])
@FunctionExamples([
        @FunctionExample(code = "<set name=\"TEMP.res\" value=\"C_AreAllActionPlansInStatuses(businessObject,'x_co8_proposal_x_ap','CLOSED,COMPLETED')\"/>"),
])
class AreAllActionPlansInStatuses extends Function{

    private static Log log = LogFactory.getLog(AreAllActionPlansInStatuses.class);
    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        PersistenceSession psession = ServiceLocator.getPersistenceSession();
        if(args[0]!=null && args[1]!=null && args[2]!=null) {
            PrimaryBusinessObject mainBusinessObject = (PrimaryBusinessObject) args[0]
            String linkTypeName =(String) args[1]
            String desirableStatuses = (String) args[2]
            Set<String> actualStatuses = getLinkedAPStatuses(linkTypeName,mainBusinessObject)
            if(actualStatuses.size()==0)
                return true
            Set<String> desirableStatusesSet = getStatusesAsSet(desirableStatuses)
            actualStatuses.removeAll(desirableStatusesSet)
            return actualStatuses.size()==0
        }
        return null
    }

    @Override
    int getArgumentCount() {
        return 3
    }

    Set<String> getLinkedAPStatuses(String linkTypeName,PrimaryBusinessObject mainBusinessObject) {
        PersistenceSession psession = ServiceLocator.getPersistenceSession();

        LinkType linkType =(LinkType) LinkType.object.fetchByExternalReference("MON",linkTypeName,psession)
        Set<LinkInstance> linkInstances = mainBusinessObject.getLinkInstancesForLinkType(linkType.getLinkTypeRk(),psession)
        if(linkInstances==null || linkInstances.size()==0)
            return new HashSet<String>()
        Set<String> linkedActionPlansStatuses = new HashSet<String>()
        for(LinkInstance linkInstance:linkInstances)
        {
            ActionPlan actionPlan = ActionPlan.object.fetch(linkInstance.getBusinessObjectRk2(),psession)
            linkedActionPlansStatuses.add(actionPlan.getActionPlanStatus().getValue())
        }
        return linkedActionPlansStatuses
    }

    Set<String> getStatusesAsSet(String desirableStatuses) {
        String[] statusesStr = desirableStatuses.split(",")
        Set<String> statuses = new HashSet<String>();
        String[] ope = statusesStr;
        int i = statusesStr.length;

        for(int test = 0; test < i; ++test) {
            String status = ope[test];
            statuses.add(status.trim());
        }
        return statuses
    }
}

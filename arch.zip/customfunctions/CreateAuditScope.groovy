package customfunctions

import com.sas.oprisk.framework.server.objects.BusinessObjectList
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.*
import com.sas.oprisk.server.behavior.SudoPersistenceSessionWrapper
import com.sas.oprisk.server.cpb.expr.function.CreateLinkInstance
import com.sas.oprisk.server.logical.DimensionalArea
import com.sas.oprisk.server.logical.DimensionalAreaHandle
import com.sas.oprisk.server.logical.LinkInstanceContainer
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.docs.*
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import com.sas.solutions.cpb.runtime.UIContext
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

import java.sql.Timestamp

/**
 * Created by Nikolay Litvyak (SAS Russia) on 16.05.2016.
 */

@FunctionDescription("Create audit scope based on auditLocation of 'Audit mission' ")
@FunctionReturnType("Boolean")
@FunctionReturnDescription("True if evaluation was successful.")
@FunctionArguments([
        @FunctionArgument(name = "scopeCreationMethod", type = "String", description = "FINANCIAL or BUSINESSLINE"),
        @FunctionArgument(name = "addOnlyKeyControls ", type = "Boolean", description = "add to scope only controls with keyflg = true"),
        @FunctionArgument(name = "createTestPlans ", type = "Boolean", description = "create tests for added controls"),
        @FunctionArgument(name = "audit", type = "Audit", description = "Audit for scope creation"),
        @FunctionArgument(name = "auditLocation", type = "DimensionalAreaHandle", description = "Dimensional Area (location field)"),
        @FunctionArgument(name = "container", type = "LinkInstanceContainer", description = "LinkInstanceContainer object")
])
@FunctionExamples([
        @FunctionExample(code = "<set name=\"TEMP.scoping\" value=\"C_CreateAuditScope('FINANCIAL',true,false,businessObject,location,linkedBusinessObjects)\"/>")
])

class CreateAuditScope extends Function {
    private static Log log = LogFactory.getLog(CreateAuditScope.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        UIContext context = getContext()
        CreateAuditScopeImpl function = new CreateAuditScopeImpl(context)
        return function.evaluate(args);
    }

    @Override
    int getArgumentCount() {
        return 6
    }
}

class CreateAuditScopeImpl {
    private static Log log = LogFactory.getLog(CreateAuditScopeImpl.class)
    private final String linkCo3ToAuditName = "x_audit_x_co3"
    private final String SourceSystemCd = "MON"
    LinkType linkCo3ToAudit
    PersistenceSession psession
    UIContext context

    Set<ControlInstance> controlsToLink
    Set<CustomObject3> finIndicatorsToLink

    private void init() {
        psession = new SudoPersistenceSessionWrapper(ServiceLocator.getPersistenceSession())
        linkCo3ToAudit = LinkType.object.fetchByExternalReference(SourceSystemCd, linkCo3ToAuditName, psession)
        controlsToLink = new HashSet<ControlInstance>()
        finIndicatorsToLink = new HashSet<CustomObject3>()
    }

    CreateAuditScopeImpl(UIContext context)
    {
        this.context = context
    }

    Object evaluate(Object[] args) throws EvaluationException {
        String method = ((String) args[0]).trim().toUpperCase()
        Boolean addOnlyKeyControls = (Boolean) args[1]
        Boolean createTestPlans = (Boolean) args[2]
        Audit audit = (Audit) args[3]
        DimensionalAreaHandle auditLocationHandle = (DimensionalAreaHandle) args[4]
        LinkInstanceContainer container = (LinkInstanceContainer) args[5]

        if (method == null || addOnlyKeyControls == null || createTestPlans == null || auditLocationHandle == null || audit == null || container == null)
            return false
        init()
        if(!audit.getCreatedFromAuditIsNull())
            return false
        if (!(isLboContainerForLinkTypeEmpty(linkCo3ToAudit, container) && isAuditControlsEmpty(audit) && isAuditTestsEmpty(audit)))
            return false
        Set<DimensionNode> auditLocation = new HashSet<DimensionNode>(auditLocationHandle.fetch(psession).getNodes(psession).toList())
//populate Controls
        if (method == "FINANCIAL")
            methodFinancial(auditLocation)
        if (method == "BUSINESSLINE")
            methodBusinessLine(auditLocation)

//Control filtering
        Set<DimensionNode> controlTypes = getDimensionNodesByDimension(auditLocation, "CONTROL")
        filterControls(controlTypes, addOnlyKeyControls)
//linking objects and test creation
        createLinksAuditToCo3(SourceSystemCd, linkCo3ToAuditName, audit, container)
        linkControls(audit)

//TODO: test creation

        if (createTestPlans)
            createTests(audit)

        return false
    }

    private void methodFinancial(Set<DimensionNode> auditLocation) {
        Set<DimensionNode> manOrgNodes = getDimensionNodesByDimension(auditLocation, "MANAGEMENT_ORG")
        Set<DimensionNode> periodsNodes = getDimensionNodesByDimension(auditLocation, "PROJECT")
        Set<DimensionNode> itSystemsNodes = getDimensionNodesByDimension(auditLocation, "RESOURCE_DIM")

        Set<DimensionNode> finIndicatorsCostCenters = new HashSet<DimensionNode>()
        List<CustomObject3> allFinIndicators = CustomObject3.ALL.execute(psession)
        for (CustomObject3 finIndicator : allFinIndicators) {
            if (!Boolean.TRUE.equals(finIndicator.getCustBooleanFieldValue("x_co3_bol_significant", psession)))
                continue
            DimensionalArea finIndicatorLocation = finIndicator.getLocation(psession)
            boolean containsManOrg = isLocationContainsNode(finIndicatorLocation, manOrgNodes)
            boolean containsPeriods = isLocationContainsNode(finIndicatorLocation, periodsNodes)
            if (containsManOrg && containsPeriods) {
                finIndicatorsCostCenters.addAll(getDimensionNodesByDimension(finIndicatorLocation.getNodes(psession).toList(), "COST_CENTER"))
                finIndicatorsToLink.add(finIndicator)
            }
        }

        List<ControlInstance> allControls = ControlInstance.ALL.execute(psession)
        for (ControlInstance control : allControls) {
            DimensionalArea controlLocation = control.getLocation(psession)
            boolean containsManOrg = isLocationContainsNode(controlLocation, manOrgNodes)
            boolean containsItSystems = isLocationContainsNode(controlLocation, itSystemsNodes)
            boolean containsCostCenter = isLocationContainsNode(controlLocation, finIndicatorsCostCenters)
            if ((containsManOrg && containsItSystems) || (containsManOrg && containsCostCenter))
                controlsToLink.add(control)
        }
    }

    private void methodBusinessLine(Set<DimensionNode> auditLocation) {
        Set<DimensionNode> manOrgNodes = getDimensionNodesByDimension(auditLocation, "MANAGEMENT_ORG")
        Set<DimensionNode> bLNodes = getDimensionNodesByDimension(auditLocation, "BL")
        Set<DimensionNode> itSystemsNodes = getDimensionNodesByDimension(auditLocation, "RESOURCE_DIM")

        List<ControlInstance> allControls = ControlInstance.ALL.execute(psession)
        for (ControlInstance control : allControls) {
            DimensionalArea controlLocation = control.getLocation(psession)
            boolean containsManOrg = isLocationContainsNode(controlLocation, manOrgNodes)
            boolean containsBls = isLocationContainsNode(controlLocation, bLNodes)
            boolean containsItSystems = isLocationContainsNode(controlLocation, itSystemsNodes)
            if ((containsManOrg && containsItSystems) || (containsManOrg && containsBls))
                controlsToLink.add(control)
        }
    }

    private void filterControls(Set<DimensionNode> controlTypes, boolean addOnlyKeyControls) {
        List<ControlInstance> filteredControls = new ArrayList<ControlInstance>()
        for (ControlInstance control : controlsToLink) {
            DimensionalArea controlLocation = control.getLocation(psession)
            boolean containsControlTypes
            boolean keyFlg
            if (controlTypes.isEmpty())
                containsControlTypes = true
            else
                containsControlTypes = isLocationContainsNode(controlLocation, controlTypes)

            if (!addOnlyKeyControls)
                keyFlg = true
            else
                keyFlg = control.getKeyFlg() == null ? false : control.getKeyFlg().booleanValue();

            if (containsControlTypes && keyFlg)
                filteredControls.add(control)
        }
        controlsToLink = filteredControls
    }

//TODO: test creation

    private void createTests(Audit audit) {
        BusinessObjectList<ControlInstance> controls = audit.getControls(psession)
        for (ControlInstance ci : controls) {
            boolean hasTestDef = ci.hasReferencesInTestDefinition(psession)

            if (hasTestDef) {
                TestDefinitionEx latestTestDef = getLatestTestDefinition(ci)
                String testDefHandle = latestTestDef.getTaggedPointerHandle()

                Object[] temp = audit.createNewTestPlans(ci.getHandle().toString(), [testDefHandle] as String[], psession)
                BusinessObjectList<TestPlan> tests = (BusinessObjectList<TestPlan>) temp[0]

//set fields from audit
                for(TestPlan test: tests) {
                    test.setDueDt((Date) context.getValue("PLANNEDENDDT"))
                }
                final String initialSaveReason = ApplicationProperties.getInitialSaveReasonTxt(psession.getLocale());
                for (TestPlan testPlan : tests) {
                    testPlan.save(initialSaveReason, psession)
                }
            }
            psession.commit()
        }
    }

    private TestDefinitionEx getLatestTestDefinition(ControlInstance control) {
        if (!control.hasReferencesInTestDefinition(psession))
            return null
        BusinessObjectList<TestDefinitionEx> testDefns = control.getTestDefinitions(psession)
        TestDefinitionEx result = null
        Timestamp min = null
        for (TestDefinitionEx testDefinition : testDefns) {
            if (testDefinition.getIsActive()) {
                Timestamp temp = testDefinition.getCreatedOnDttm()
                if (min == null) {
                    min = temp
                    result = testDefinition
                } else {
                    min = min > temp ? temp : min
                    if (min > temp) {
                        min = temp
                        result = testDefinition
                    }
                }
            }
        }
        return result
    }

    private boolean isLocationContainsNode(DimensionalArea location, Collection<DimensionNode> nodes) {
        boolean locationContainsNode = false;
        for (DimensionNode dimensionNode : nodes)
            if (location.containsNode(dimensionNode, psession))
                locationContainsNode = true
        return locationContainsNode
    }

    private Set<DimensionNode> getDimensionNodesByDimension(Collection<DimensionNode> dimensionalPoints, String dimension) {
        Set<DimensionNode> targetDimensionalPoints = new HashSet<DimensionNode>()
        for (DimensionNode node : dimensionalPoints) {
            if (node.getDimension().getSqlName() == dimension)
                targetDimensionalPoints.add(node)
        }
        return targetDimensionalPoints
    }

    private void createLinksAuditToCo3(String linkTypeSourceSystemCd, String linkTypeId, Audit audit, LinkInstanceContainer container) {
        CreateLinkInstance creator = new CreateLinkInstance()
        for (CustomObject3 co3 : finIndicatorsToLink) {
            creator.evaluate(linkTypeSourceSystemCd, linkTypeId, audit, co3.getTaggedPointerHandle().toString(), container)
        }
    }

    private void linkControls(Audit audit) {
        for (ControlInstance controlInstance : controlsToLink)
            audit.addToTestExecutionContexts(controlInstance, psession)
    }

    private boolean isLboContainerForLinkTypeEmpty(LinkType linkType, LinkInstanceContainer container) {
        if (linkType == null)
            return false
        Map<Long, LinkInstance> existingLinks = container.getLinkInstanceMap(linkType.getLinkTypeRk())
        if (existingLinks.size() > 0)
            return false
        return true
    }

    private boolean isAuditTestsEmpty(Audit audit) {
        List<TestPlan> tests = audit.getAllCachedTests()
        return tests.size() == 0
    }

    private boolean isAuditControlsEmpty(Audit audit) {
        if (audit.getControls(psession).size() > 0)
            return false
        return true
    }
}
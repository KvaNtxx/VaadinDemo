package customfunctions

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.monitor.web.AppRequestContext
import com.sas.oprisk.monitor.web.AppRequestContextHolder
import com.sas.oprisk.server.behavior.PrimaryBusinessObject
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.oprisk.server.workflow.WorkflowUtil
import com.sas.solutions.cpb.docs.*
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import com.sas.workflow.framework.client.Task
import com.sas.workflow.framework.client.Transition
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
import javax.servlet.http.HttpServletRequest
/**
 * Created by Nikolay Litvyak (SAS Russia) on 14.03.2016.
 */
@FunctionDescription("Return id of pressed menu button.'save','apply' or '%workflowStatusId%'.")
@FunctionReturnType("String")
@FunctionReturnDescription("Invoked action")
@FunctionArguments([
        @FunctionArgument(name = "object", type = "PrimaryBusinessObject", description = "current Business Object with workflow")
])
@FunctionExamples([
        @FunctionExample(code = "<set name=\"TEMP.action\" value=\"c_C_GetInvokedAction(businessObject)\"/>"),
])
class GetInvokedAction extends Function {
    private static Log log = LogFactory.getLog(GetInvokedAction.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        PrimaryBusinessObject businessObject = (PrimaryBusinessObject) args[0];
        final AppRequestContext appCtx = AppRequestContextHolder.getRequestContext();
        HttpServletRequest request = appCtx.getRequest()
        String method = request.getParameter("method")
        if (method == "save") {
            if (request.getParameter("apply") == "true")
                return "apply"
            return "save"
        }
        if (method == "doWorkflow") {
            String workflowStatusId = request.getParameter("workflowStatusId")
            Task process = WorkflowUtil.getProcessInstance(businessObject)
            Task workableActivity = WorkflowUtil.getWorkableActivity(process, psession)
            Collection<Transition> transitions = WorkflowUtil.getStatuses(workableActivity)
            String transactionLabel = null
            for (Transition transition : transitions) {
                if (workflowStatusId == transition.getId())
                    transactionLabel = transition.getLabel()
            }
            return transactionLabel
        }
        return null
    }

    @Override
    int getArgumentCount() {
        return 0
    }
}

package customfunctions

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.behavior.StructuredBusinessObject
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.docs.FunctionArgument
import com.sas.solutions.cpb.docs.FunctionArguments
import com.sas.solutions.cpb.docs.FunctionDescription
import com.sas.solutions.cpb.docs.FunctionExample
import com.sas.solutions.cpb.docs.FunctionExamples
import com.sas.solutions.cpb.docs.FunctionReturnDescription
import com.sas.solutions.cpb.docs.FunctionReturnType
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

/**
 * Created by Nikolay Litvyak (SAS Russia) on 18.03.2016.
 */
@FunctionDescription("Return parent name of passed DimensionNode in 'ru' Locale" )
@FunctionReturnType("String")
@FunctionReturnDescription("Parent name")
@FunctionArguments([
        @FunctionArgument(name = "dimensionNode", type = "DimensionNode", description = "child Dimensional Node"),
        @FunctionArgument(name = "distance", type = "Integer", description = "distance between dimensionNode and desirable parent (0-9)"),
])
@FunctionExamples([
        @FunctionExample(code = "<set name=\"TEMP.name\" value=\"c_GetDimPointParentName(getNodeByDimension(pointLocation,'BusinessLine',null),1)\"/>"),
])
class GetDimPointParentName extends Function {
    private static Log log = LogFactory.getLog(GetDimPointParentName.class)
    public static final String DIM_NODE_GROUP_FLG_FIELD_NM = "x_is_group"

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        StructuredBusinessObject dimensionalNode = (StructuredBusinessObject) args[0]
        Integer levelDistance = (Integer) args[1]

        if (levelDistance == null)
            throw new IllegalArgumentException("One or more required parameters  are null")
        if (levelDistance > 9 || levelDistance < 0)
            throw new IllegalArgumentException("Invalid distance")
        if (dimensionalNode == null)
            return null

        StructuredBusinessObject parent = getParent(levelDistance, dimensionalNode, psession)
        if (parent == null)
            return null

        return parent.getName(new Locale("ru"))
    }

    @Override
    int getArgumentCount() {
        return 2
    }

    private StructuredBusinessObject getParent(int levelDistance, StructuredBusinessObject childNode, PersistenceSession psession) {

        StructuredBusinessObject parent = childNode

        while (levelDistance > 0 && parent != null) {
            parent = parent.getDefaultParent(psession)
            levelDistance--

            Boolean groupLimitField = parent.getCustBooleanFieldValue(DIM_NODE_GROUP_FLG_FIELD_NM, psession);
            if (Boolean.TRUE.equals(groupLimitField))
                return null
        }

        if (parent != null && parent.isDefaultRoot())
            return null

        return parent
    }
}

package customfunctions

import com.sas.oprisk.framework.server.OpRiskException
import com.sas.oprisk.framework.server.objects.BusinessObjectList
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.framework.server.query.Query
import com.sas.oprisk.framework.server.query.QueryConstraint
import com.sas.oprisk.server.DimensionNode
import com.sas.oprisk.server.FinancialImpact
import com.sas.oprisk.server.ImpactDetail
import com.sas.oprisk.server.base.DimensionalPointQueryVariable
import com.sas.oprisk.server.base.FinancialImpactQuery
import com.sas.oprisk.server.base.FinancialImpactQueryVariable
import com.sas.oprisk.server.behavior.StructuredBusinessObject
import com.sas.oprisk.server.behavior.SudoPersistenceSessionWrapper
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.docs.*
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
import org.joda.time.LocalDate

/**
 * Created by Nikolay Litvyak (SAS Russia) on 03.03.2016.
 */
@FunctionDescription("Calculate total of all baseLossAmt for all Impact Details filtered financialStatusCd, for all Financial Impacts filtered by impactTypeCd and validationStateCd under specified parent (except for Default Root) of passed DimensionNode")
@FunctionReturnType("Double")
@FunctionReturnDescription("Total value")
@FunctionArguments([
        @FunctionArgument(name = "dimensionNode", type = "DimensionNode", description = "child Dimensional Node"),
        @FunctionArgument(name = "distance", type = "Integer", description = "distance between dimensionNode and desirable parent (0-9)"),
        @FunctionArgument(name = "validationStateCd", type = "String", description = "validationStateCd to filter Financial Impacts")
])
@FunctionExamples([
        @FunctionExample(code = "<set name=\"TEMP.total\" value=\"c_GetLossByDimension(getNodeByDimension(pointLocation,'BusinessLine',null),1,'NIP')\"/>"),
])
class GetLossByDimension extends Function {

    private static Log log = LogFactory.getLog(GetLossByDimension.class)
    public static final String RENEWABLE_FLAG_NM = "x_renewable_limit"
    public static final String IMPACT_DETAIL_TYPE_SET = "SET"
    public static final String IMPACT_DETAIL_TYPE_NRM = "NRM"
    public static final String FIN_IMPACT_TYPE = "LOSS"
    public static final String DIM_NODE_SUM_FIELD_NM = "x_limit_sum"
    public static final String DIM_NODE_GROUP_FLG_FIELD_NM = "x_is_group"

    @Override
    Object evaluate(Object[] args) throws EvaluationException {

        PersistenceSession psession = new SudoPersistenceSessionWrapper(ServiceLocator.getPersistenceSession())
        StructuredBusinessObject dimensionalNode = (StructuredBusinessObject) args[0]
        Integer levelDistance = (Integer) args[1]
        String validationStateCd = (String) args[2]

        if (levelDistance == null || validationStateCd == null)
            throw new IllegalArgumentException("One or more required parameters  are null")
        if (levelDistance > 9 || levelDistance < 0)
            throw new IllegalArgumentException("Invalid distance")
        if (dimensionalNode == null)
            return null

        StructuredBusinessObject parent = getParent(levelDistance, dimensionalNode, psession)
        if (parent == null)
            return null

        BusinessObjectList<FinancialImpact> financialImpacts = getFinancialImpactsUnder(parent, FIN_IMPACT_TYPE, validationStateCd, psession)
        return calculateLoss(financialImpacts, parent, psession)
    }

    private Double calculateLoss(BusinessObjectList<FinancialImpact> financialImpacts, StructuredBusinessObject parent, PersistenceSession psession) {
        double total = 0d
        double setAmount = 0d
        double nrmAmount = 0d
        Double limitSum = parent.getCustNumericFieldValue(DIM_NODE_SUM_FIELD_NM, psession)
        LocalDate currentDate = new LocalDate(new Date());
        if (limitSum == null)
            return null

        Boolean x_limit_renewable = parent.getCustBooleanFieldValue(RENEWABLE_FLAG_NM, psession)
        if (x_limit_renewable == Boolean.TRUE) {
            for (FinancialImpact fi : financialImpacts) {
                setAmount += getLoss(fi, IMPACT_DETAIL_TYPE_SET, currentDate, psession)
                nrmAmount += getLoss(fi, IMPACT_DETAIL_TYPE_NRM, currentDate, psession)
            }
            total = setAmount + nrmAmount
        }

        if (x_limit_renewable == null || x_limit_renewable == Boolean.FALSE) {
            for (FinancialImpact fi : financialImpacts)
                setAmount += getLoss(fi, IMPACT_DETAIL_TYPE_SET, currentDate, psession)
            total = setAmount
        }

        return limitSum - total
    }

    private StructuredBusinessObject getParent(int levelDistance, StructuredBusinessObject childNode, PersistenceSession psession) {

        StructuredBusinessObject parent = childNode

        while (levelDistance > 0 && parent != null) {
            parent = parent.getDefaultParent(psession)
            levelDistance--

            Boolean groupLimitField = parent.getCustBooleanFieldValue(DIM_NODE_GROUP_FLG_FIELD_NM, psession);
            if (Boolean.TRUE.equals(groupLimitField))
                return null
        }

        if (parent != null && parent.isDefaultRoot())
            return null

        return parent
    }

    private BusinessObjectList<FinancialImpact> getFinancialImpactsUnder(StructuredBusinessObject parent, String finImpactType, String validationStateCd, PersistenceSession psession) {

        FinancialImpactQuery query = FinancialImpact.ALL
        FinancialImpactQueryVariable fiQV = query.result()
        DimensionalPointQueryVariable dpQV = new DimensionalPointQueryVariable("dp")
        List<QueryConstraint> constraints = ((DimensionNode) parent).asDimensionalPoint(psession).getConstraintsForPointsUnder(dpQV, psession)
        constraints.add(Query.equalTo(fiQV.pointLocation.raw(), dpQV.dimPointRk))
        constraints.add(Query.equalTo(fiQV.impactTypeCd, finImpactType))
        constraints.add(Query.equalTo(fiQV.validationStateCd, validationStateCd))
        constraints.add(Query.equalTo(fiQV.isAllocationFlg, Boolean.FALSE))
//        log.warn("DEBUG SQL=" + DynamicSqlFormatter.format((SqlPersistenceStrategy) (psession.getStrategy()), ObjectToSqlTransformer.transform(query.withConstraints(constraints).baseQuery.asObjectQuery()), new HashMap<String, FilledHole>(0)))
        BusinessObjectList<FinancialImpact> targetFinancialImpacts = query.withConstraints(constraints).execute(psession)
        return targetFinancialImpacts
    }

    private double getLoss(FinancialImpact fi, String financialStatusCd, LocalDate currentDate, PersistenceSession psession) throws OpRiskException {
        double total = 0d;
        final BusinessObjectList<ImpactDetail> impactDetails = fi.getDetails(psession)
        for (ImpactDetail im : impactDetails) {
            if (isDateInsideInterval(currentDate, im.getLossDt(), im.getSettlementDt()))
                if (financialStatusCd.equals(im.getFinancialStatusCd())) {
                    final Double baseLossAmt = im.getBaseLossAmt()
                    if (baseLossAmt != null)
                        total += baseLossAmt
                }
        }
        return total
    }

    @SuppressWarnings("GroovyVariableNotAssigned")
    private boolean isDateInsideInterval(LocalDate date, Date min, Date max) {
//        log.warn("DEBUG " + date + " " + min + " " + max + (date.compareTo(min) >= 0 && date.compareTo(max) <= 0))
        LocalDate ldMin, ldMax

        if (min == null && max == null)
            return true

        if (min != null)
            ldMin = new LocalDate(min)
        if (max != null)
            ldMax = new LocalDate(max)

        if (min == null) {
            if (date.compareTo(ldMax) <= 0)
                return true
        }
        if (max == null) {
            if (date.compareTo(ldMin) >= 0)
                return true
        }
        return date.compareTo(ldMin) >= 0 && date.compareTo(ldMax) <= 0
    }

    @Override
    int getArgumentCount() {
        return 3
    }
}

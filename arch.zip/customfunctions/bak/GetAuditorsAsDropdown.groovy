package customfunctions.bak

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.Audit
import com.sas.oprisk.server.LinkInstance
import com.sas.oprisk.server.LinkType
import com.sas.oprisk.server.User
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
import org.apache.struts.util.LabelValueBean

/**
 * Created by rusnli on 15.02.2016.
 */
class GetAuditorsAsDropdown extends Function{
    private static Log log = LogFactory.getLog(GetAuditorsAsDropdown.class);

    private final String linkAuditToUsersName = "x_audit_x_auditors"
    private final String SourceSystemCd = "MON"


    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        LinkInstance linkInstance = (LinkInstance) args[0]
        Audit audit = Audit.object.fetchIfExists(linkInstance.getBusinessObjectRk1(),psession)
        if(audit==null)
            return null

        LinkType linkType = LinkType.object.fetchIfExistsByExternalReference(SourceSystemCd,linkAuditToUsersName,psession)
        Set<LinkInstance> auditorsLinkInstances = audit.getLinkInstancesForLinkType(linkType.getLinkTypeRk(),psession)
        if(auditorsLinkInstances==null)
            return null
        Set<User> auditors= new HashSet<User>()
        List<LabelValueBean> auditorsNames= new ArrayList<LabelValueBean>()
        for(LinkInstance link : auditorsLinkInstances)
        {
            User user = User.object.fetch( link.getBusinessObjectRk2(),psession)
            auditors.add(user)
            auditorsNames.add(new LabelValueBean(user.getDisplayNm(),user.getUserId()))
        }
        return auditorsNames
    }

    @Override
    int getArgumentCount() {
        return 0
    }
}

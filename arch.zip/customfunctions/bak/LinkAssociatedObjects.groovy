package customfunctions.bak

import com.sas.oprisk.framework.server.objects.BusinessObject
import com.sas.oprisk.framework.server.objects.BusinessObjectList
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.Audit
import com.sas.oprisk.server.ControlInstance
import com.sas.oprisk.server.CustomObject3
import com.sas.oprisk.server.DimensionNode
import com.sas.oprisk.server.LinkInstance
import com.sas.oprisk.server.LinkType
import com.sas.oprisk.server.behavior.PrimaryBusinessObject
import com.sas.oprisk.server.cpb.expr.function.CreateLinkInstance
import com.sas.oprisk.server.logical.DimensionalArea
import com.sas.oprisk.server.logical.DimensionalAreaHandle
import com.sas.oprisk.server.logical.LinkInstanceContainer
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

/**
 * Created by rusnli on 11.02.2016.
 */
class LinkAssociatedObjects extends Function{
    private static Log log = LogFactory.getLog(LinkAssociatedObjects.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        Audit audit = (Audit) args[0]
        DimensionalAreaHandle location = (DimensionalAreaHandle) args[1]
        LinkInstanceContainer container = (LinkInstanceContainer) args[2]
        if (location == null || audit == null || container == null)
            return -1
        List<DimensionNode> dimensionalNodes = location.fetch(psession).getNodes(psession).toList()
        List<DimensionNode> manOrgDimensions = getDimensionNodesByDimension(dimensionalNodes,"MANAGEMENT_ORG")
        List<DimensionNode> periods = getDimensionNodesByDimension(dimensionalNodes,"AUX_RPT_DIM_1")
        List<DimensionNode> itSystems = getDimensionNodesByDimension(dimensionalNodes,"PROJECT")

        List<CustomObject3> allFinIndicators = CustomObject3.ALL.execute(psession)
        List<CustomObject3> targetFinIndicators = new BusinessObjectList<CustomObject3>()
        for(CustomObject3 finIndicator:allFinIndicators)
        {
            boolean containsManOrg = false;
            boolean containsPeriods = false;
            DimensionalArea finIndicatorLocation = finIndicator.getLocation(psession)
            for(DimensionNode dimensionNode:manOrgDimensions)
                if(finIndicatorLocation.containsNode(dimensionNode,psession))
                    containsManOrg=true
            for(DimensionNode dimensionNode:periods)
                if(finIndicatorLocation.containsNode(dimensionNode,psession))
                    containsPeriods=true
            if(containsManOrg && containsPeriods)
                targetFinIndicators.add(finIndicator)
        }
//        clearContainerForLinkType("MON","FIN_AUDIT_CO3",container)
        createLinks("MON","FIN_AUDIT_CO3",audit,targetFinIndicators,container)
        return targetFinIndicators.size()

//        FIN_AUDIT_CO3
    }

    @Override
    int getArgumentCount() {
        return 0
    }

    private List<DimensionNode> getDimensionNodesByDimension(List<DimensionNode> dimensionalPoints, String dimension) {
        List<DimensionNode> targetDimensionalPoints = new ArrayList<DimensionNode>()
        for(DimensionNode node :dimensionalPoints)
        {
            if(node.getDimension().getSqlName()==dimension)
                targetDimensionalPoints.add(node)
        }
        return targetDimensionalPoints
    }

/*
    private void createLinks(String LINK_TYPE_SOURCE_SYSTEM_CD,String LINK_TYPE_CO1, PrimaryBusinessObject hostBusinessObject,Set<String> handleList, LinkInstanceContainer container)
    {
        CreateLinkInstance creator = new CreateLinkInstance()
        for(String handle: handleList)
        {
            creator.evaluate(LINK_TYPE_SOURCE_SYSTEM_CD,LINK_TYPE_CO1,hostBusinessObject,handle,container)
        }
    }
*/
    private void createLinks(String linkTypeSourceSystemCd,String linkTypeId, PrimaryBusinessObject audit,List<CustomObject3> targetFinIndicators, LinkInstanceContainer container)
    {

        CreateLinkInstance creator = new CreateLinkInstance()
        for(CustomObject3 co3: targetFinIndicators)
        {
            creator.evaluate(linkTypeSourceSystemCd,linkTypeId,co3,audit.getTaggedPointerHandle().toString(),container)
        }
    }

    private void clearContainerForLinkType(String linkTypeSourceSystemCd,String linkTypeId,LinkInstanceContainer container)
    {
        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        LinkType linkType = LinkType.object.fetchIfExistsByExternalReference(linkTypeSourceSystemCd,linkTypeId,psession)
        if(linkType==null)
            return
        Map<Long, LinkInstance> existingLinks = container.getLinkInstanceMap(linkType.getLinkTypeRk())
        if(existingLinks.size()==0)
            return
        long[] existingLinksRk = (Long[]) existingLinks.keySet().toArray()
        container.removeAll(existingLinksRk,linkType.getLinkTypeRk())
    }

    private Set<String> getTaggedPointHandles(BusinessObjectList<PrimaryBusinessObject> primaryBusinessObjects)
    {
        Set<String> handles = new HashSet<String>()
        for(PrimaryBusinessObject primaryBusinessObject:primaryBusinessObjects)
        {
            handles.add(primaryBusinessObject.getTaggedPointerHandle().toString())
        }
        return handles

    }

























    /*
    private void linkControls( Audit audit,String LINK_TYPE_SOURCE_SYSTEM_CD="MON")
    {
        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        BusinessObjectList<ControlInstance> controlInstances = ControlInstance.ALL.execute(psession)

        for(ControlInstance controlInstance:controlInstances)
            audcontrolInstances.get(0).it.addToTestExecutionContexts(controlInstance,psession)
    }
*/
}

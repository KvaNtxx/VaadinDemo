package com.sas.cpb.customFunctions;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sas.oprisk.framework.server.FrameworkConstants;
import com.sas.oprisk.framework.server.OpRiskException;
import com.sas.oprisk.framework.server.persistence.PersistenceSession;
import com.sas.oprisk.server.AssessmentPeriod;
import com.sas.oprisk.server.services.ServiceLocator;
import com.sas.solutions.cpb.docs.*;
import com.sas.solutions.cpb.expr.function.Function;
import com.sas.solutions.cpb.runtime.EvaluationException;

@FunctionOwner("splgrt")
@FunctionDescription("The c_getAssessmentPeriodById() function returns assessment period.")
@FunctionArguments([
    @FunctionArgument(
            name = "sourceSystem", 
            type = "String", 
            description = "Assessment period source system"),
    @FunctionArgument(
            name = "periodId", 
            type = "String", 
            description = "Assessment period id") 
])
@FunctionReturnType("AssessmentPeriod")
@FunctionSince(added = "5.1 SPL", current = FrameworkConstants.APP_VERSION)
public class GetAssessmentPeriodById extends Function {
    private static final Log logger = LogFactory.getLog(GetAssessmentPeriodById.class);


    public Object evaluate(Object[] args) throws EvaluationException {
        String sourceSystemCd = (String) args[0];
        String objectId       = (String) args[1];
        if (args[0] != null) {
            try {
                PersistenceSession psession = ServiceLocator.getPersistenceSession();
                return AssessmentPeriod.object.fetchIfExistsByExternalReference(sourceSystemCd, objectId, psession);
            } catch (OpRiskException e) {
                logger.warn("Cannot find requested AssessmentPeriod. sourceSystemCd=" + sourceSystemCd + " objectId="+objectId);
            } catch (ClassCastException cce) {
                logger.warn("Cannot find requested AssessmentPeriod. sourceSystemCd=" + sourceSystemCd +
                        " objectId="+objectId + " " + cce.getLocalizedMessage());
            }
        }
        return null;
    }

    @Override
    public int getArgumentCount() {
        return 2;
    }

}

package customfunctions

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.Audit
import com.sas.oprisk.server.ControlInstance
import com.sas.oprisk.server.TestPlan
import com.sas.oprisk.server.User
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

class GetAuditLinkedControlOwners extends Function {
    private static Log log = LogFactory.getLog(GetAuditLinkedControlOwners.class);

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        if (args[0] == null)
            return null
        Audit audit = (Audit) args[0];

        String owners = ""
        List<ControlInstance> controlInstances = audit.getControls(psession)
        Set<ControlInstance> targetControlInstances = new HashSet<ControlInstance>()
        List<TestPlan> tests = audit.getAllCachedTests()
        HashSet<User> uniqueUsers = new HashSet<User>()

        for (TestPlan testPlan : tests) {
            ControlInstance controlInstance = testPlan.getControl(psession)
            if (controlInstances.contains(controlInstance))
                targetControlInstances.add(controlInstance)

        }

        for (ControlInstance controlInstance : targetControlInstances) {
            User owner = controlInstance.getOwner(psession)
            if (!uniqueUsers.add(owner))
                continue
            if (owner == null)
                continue
            owners += owner.getUserId() + ","
        }
        if (owners.length() > 1)
            owners = owners.substring(0, owners.length() - 1)
        return owners
    }

    @Override
    int getArgumentCount() {
        return 1
    }
}

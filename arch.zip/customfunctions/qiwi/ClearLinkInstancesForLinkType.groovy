package customfunctions

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.LinkInstance
import com.sas.oprisk.server.LinkType
import com.sas.oprisk.server.logical.LinkInstanceContainer
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

/**
 * Created by rusnli on 16.02.2016.
 */
class ClearLinkInstancesForLinkType extends Function {

    private static Log log = LogFactory.getLog(ClearLinkInstancesForLinkType.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {

        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        if (args[0] == null || args[1] == null || args[2] == null)
            return false
        String SourceSystemCd = (String) args[0]
        String linkTypeName = (String) args[1]
        LinkInstanceContainer container = (LinkInstanceContainer) args[2]
        LinkType linkType = LinkType.object.fetchIfExistsByExternalReference(SourceSystemCd, linkTypeName, psession)
        Map<Long, LinkInstance> existingLinkInstances = container.getLinkInstanceMap(linkType.getLinkTypeRk())
        container.removeAll(existingLinkInstances.keySet().toArray() as long[], linkType.getLinkTypeRk())
        return true
    }

    @Override
    int getArgumentCount() {
        return 3
    }
}

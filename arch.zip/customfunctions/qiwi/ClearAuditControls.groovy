package customfunctions
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.Audit
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
/**
 * Created by rusnli on 15.02.2016.
 */
class ClearAuditControls extends Function {

    private static Log log = LogFactory.getLog(ClearAuditControls.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        if(args[0] == null)
            return false
        Audit audit = (Audit) args[0]
        audit.deleteTestExecutionContexts(psession)
        return true
    }

    @Override
    int getArgumentCount() {

        return 1
    }
}

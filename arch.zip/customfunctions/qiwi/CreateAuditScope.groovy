package customfunctions.qiwi

import com.sas.oprisk.framework.server.objects.BusinessObjectList
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.*
import com.sas.oprisk.server.behavior.SudoPersistenceSessionWrapper
import com.sas.oprisk.server.cpb.expr.function.CreateLinkInstance
import com.sas.oprisk.server.logical.DimensionalArea
import com.sas.oprisk.server.logical.DimensionalAreaHandle
import com.sas.oprisk.server.logical.LinkInstanceContainer
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.docs.*
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import com.sas.solutions.cpb.runtime.UIContext
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

import java.sql.Timestamp

/**
 * Created by Nikolay Litvyak (SAS Russia) on 15.06.2016.
 */

@FunctionDescription("Create audit scope based on auditLocation of 'Audit mission' ")
@FunctionReturnType("Boolean")
@FunctionReturnDescription("True if evaluation was successful.")
@FunctionArguments([
        @FunctionArgument(name = "scopeCreationMethod", type = "String", description = "FINANCIAL or BUSINESSLINE"),
        @FunctionArgument(name = "addOnlyKeyControls ", type = "Boolean", description = "add to scope only controls with keyflg = true"),
        @FunctionArgument(name = "createTestPlans ", type = "Boolean", description = "create tests for added controls"),
        @FunctionArgument(name = "audit", type = "Audit", description = "Audit for scope creation"),
        @FunctionArgument(name = "auditLocation", type = "DimensionalAreaHandle", description = "Dimensional Area (location field)"),
        @FunctionArgument(name = "container", type = "LinkInstanceContainer", description = "LinkInstanceContainer object")
])
@FunctionExamples([
        @FunctionExample(code = "<set name=\"TEMP.scoping\" value=\"C_CreateAuditScope('FINANCIAL',true,false,businessObject,location,linkedBusinessObjects)\"/>")
])

class CreateAuditScope extends Function {
    private static Log log = LogFactory.getLog(CreateAuditScope.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        UIContext context = getContext()
        CreateAuditScopeImpl function = new CreateAuditScopeImpl(context)
        return function.evaluate(args)
    }

    @Override
    int getArgumentCount() {
        return 6
    }
}

class CreateAuditScopeImpl {
    private static Log log = LogFactory.getLog(CreateAuditScopeImpl.class)

    static final Dimension MANAGEMENT_ORG = Dimension.managementOrg
    static final Dimension PERIOD = Dimension.auxRptDim1
    static final Dimension IT_SYSTEM = Dimension.project
    static final Dimension FIN_REPORT = Dimension.auxOpDim1
    // gchinsky 03-07-2016: added control dimension
    static final Dimension CONTROL_TYPE = Dimension.control
    static final String KEY_FIN_INDICATOR_FLG = "x_prizn"
    static final String AUDIT_X_FIN_INDICATOR = "AUDIT_FIN_CO3"
    static final String SOURCE_SYSTEM_CD = "MON"

    LinkType linkCo3ToAudit
    PersistenceSession psession
    UIContext context

    Set<ControlInstance> controlsToLink
    Set<CustomObject3> finIndicatorsToLink

    private void init() {
        psession = new SudoPersistenceSessionWrapper(ServiceLocator.getPersistenceSession())
        linkCo3ToAudit = LinkType.object.fetchIfExistsByExternalReference(SOURCE_SYSTEM_CD, AUDIT_X_FIN_INDICATOR, psession)
        if (linkCo3ToAudit == null)
            throw new NullPointerException("Cannot find Link Type: " + AUDIT_X_FIN_INDICATOR + " with SourceSystemCd: " + SOURCE_SYSTEM_CD)
        controlsToLink = new HashSet<ControlInstance>()
        finIndicatorsToLink = new HashSet<CustomObject3>()
    }

    CreateAuditScopeImpl(UIContext context) {
        this.context = context
    }

    Object evaluate(Object[] args) throws EvaluationException {
        String method = ((String) args[0]).trim().toUpperCase()
        Boolean addOnlyKeyControls = (Boolean) args[1]
        Boolean createTestPlans = (Boolean) args[2]
        Audit audit = (Audit) args[3]
        DimensionalAreaHandle auditLocationHandle = (DimensionalAreaHandle) args[4]
        LinkInstanceContainer container = (LinkInstanceContainer) args[5]

        if (method == null || addOnlyKeyControls == null || createTestPlans == null || auditLocationHandle == null || audit == null || container == null) {
            log.warn("CF ERROR: One or more required arguments are null")
            return false
        }
        init()
        if (!audit.getCreatedFromAuditIsNull()) {
            log.warn("CF WARN: You cannot autoscope audit created from another audit")
            return false
        }
        if (!(isLboContainerForLinkTypeEmpty(linkCo3ToAudit, container) && isAuditControlsEmpty(audit) && isAuditTestsEmpty(audit))) {
            log.warn("CF ERROR: One or more objects container are not empty")
            return false
        }
        Set<DimensionNode> auditLocation = new HashSet<DimensionNode>(auditLocationHandle.fetch(psession).getNodes(psession).toList())
//populate Controls
        if (method == "MANUAL")
            return true
        if (method == "FINANCIAL")
            methodFinancial(auditLocation, addOnlyKeyControls)

//linking objects and test creation
        createLinksAuditToCo3(SOURCE_SYSTEM_CD, AUDIT_X_FIN_INDICATOR, audit, container)
        linkControls(audit)

        if (createTestPlans)
            createTests(audit)
        return false
    }

    private void methodFinancial(Set<DimensionNode> auditLocation, boolean addOnlyKeyControls) {
        HashMap<Set<DimensionNode>, CustomObject3> finIndicatorsMap = new HashMap<Set<DimensionNode>, CustomObject3>()

        Set<DimensionNode> manOrgNodes = getDimensionNodesByDimension(auditLocation, MANAGEMENT_ORG)
        Set<DimensionNode> periodsNodes = getDimensionNodesByDimension(auditLocation, PERIOD)
        Set<DimensionNode> itSystemsNodes = getDimensionNodesByDimension(auditLocation, IT_SYSTEM)
        // gchinsky 03-07-2016: get control types from audit
        Set<DimensionNode> controlTypeNodes = getDimensionNodesByDimension(auditLocation, CONTROL_TYPE)
        Set<DimensionNode> finIndicatorsFinReports = new HashSet<DimensionNode>()
        List<CustomObject3> allFinIndicators = CustomObject3.ALL.execute(psession)
        //boolean isControlTypeDefined = (controlTypeNodes.size() > 0)
        boolean isItSystemDefined = (itSystemsNodes.size() > 0)

        for (CustomObject3 finIndicator : allFinIndicators) {
            DimensionalArea finIndicatorLocation = finIndicator.getLocation(psession)
            boolean containsManOrg = isLocationContainsNode(finIndicatorLocation, manOrgNodes)
            boolean containsPeriods = isLocationContainsNode(finIndicatorLocation, periodsNodes)
            if (containsManOrg && containsPeriods) {
                log.warn("CF DEBUG 1: " + finIndicator)
                log.warn("CF DEBUG 2: " + addNewestFinIndicator(finIndicator, finIndicatorsMap))
            }
        }
        log.warn("CF DEBUG 3: " + finIndicatorsMap.values())

        Collection<CustomObject3> finIndicatorsAll = finIndicatorsMap.values()
        for (CustomObject3 finIndicator : finIndicatorsAll) {
            if (Boolean.TRUE.equals(finIndicator.getCustBooleanFieldValue(KEY_FIN_INDICATOR_FLG, psession))) {
                finIndicatorsToLink.add(finIndicator)
                finIndicatorsFinReports.addAll(getDimensionNodesByDimension(finIndicator.getLocation(psession).getNodes(psession).toList(), FIN_REPORT))
            }
        }
        List<ControlInstance> allControls = ControlInstance.ALL.execute(psession)
        for (ControlInstance control : allControls) {
            DimensionalArea controlLocation = control.getLocation(psession)
            boolean containsManOrg = isLocationContainsNode(controlLocation, manOrgNodes)
            //boolean containsItSystems = isLocationContainsNode(controlLocation, itSystemsNodes)
            boolean containsFinReports = isLocationContainsNode(controlLocation, finIndicatorsFinReports)
            // gchinsky 03-06-2016: does the control contain the same control types as the audit
            boolean containsControlTypes = isLocationContainsNode(controlLocation, controlTypeNodes)

            if (containsManOrg && containsFinReports) {
                if (addOnlyKeyControls) {
                    if (Boolean.TRUE.equals(control.getKeyFlg()))
                        controlsToLink.add(control)
                } else
                    controlsToLink.add(control)
            }

            // gchinsky 03-07-2016: add by control types and filter by it systems additionally
            if (containsManOrg && containsControlTypes) {
                if (isItSystemDefined) {
                    if (isLocationContainsNode(controlLocation, itSystemsNodes)) {
                        controlsToLink.add(control)
                    }
                }
                else {
                    controlsToLink.add(control)
                }
            }
            /* gchinsky 03-07-2016: removed due to different logic above
            if (containsManOrg && containsItSystems) {
                controlsToLink.add(control)
            }
            */
        }
    }

    //return true if FinIndicator new or newer than existing for (MANAGEMENT_ORG and PERIOD) dimensions
    private boolean addNewestFinIndicator(CustomObject3 finIndicator, HashMap<Set<DimensionNode>, CustomObject3> finIndicators) {

        Set<DimensionNode> nodes = new HashSet<DimensionNode>()
        DimensionalArea location = finIndicator.getLocation(psession)
        DimensionNode managementOrg = location.getFirstNodeByDimension(MANAGEMENT_ORG, psession)
        DimensionNode period = location.getFirstNodeByDimension(PERIOD, psession)
        // gchinsky 03-08-2016: select financial statement
        DimensionNode finStatement = location.getFirstNodeByDimension(FIN_REPORT, psession)
        if (managementOrg == null || period == null || finStatement == null) {
            return false
        }
        nodes.add(managementOrg)
        nodes.add(period)
        nodes.add(finStatement)

        if (finIndicators.containsKey(nodes)) {
            CustomObject3 existing = finIndicators.get(nodes)
            if (finIndicator.getCreatedDttm() > existing.getCreatedDttm()) {
                finIndicators.put(nodes, finIndicator)
                return true
            } else {
                return false
            }
        } else {
            finIndicators.put(nodes, finIndicator)
            return true
        }
    }

    private void createTests(Audit audit) {
        BusinessObjectList<ControlInstance> controls = audit.getControls(psession)
        for (ControlInstance ci : controls) {
            boolean hasTestDef = ci.hasReferencesInTestDefinition(psession)
            // gchinsky 03-07-2015: get control owner user to add into custom field x_ctrl_owner in testplan
            User owner = ci.getOwner(psession)

            if (hasTestDef) {
                TestDefinitionEx latestTestDef = getLatestTestDefinition(ci)
                if (latestTestDef == null) {
                    continue
                }
                String testDefHandle = latestTestDef.getTaggedPointerHandle()

                Object[] temp = audit.createNewTestPlans(ci.getHandle().toString(), [testDefHandle] as String[], psession)
                BusinessObjectList<TestPlan> tests = (BusinessObjectList<TestPlan>) temp[0]

//set fields from audit
                for (TestPlan test : tests) {
                    test.setCustDateFieldValue("plannedStartDt", (Date) context.getValue("plannedStartDt"), psession)
                    test.setCustDateFieldValue("plannedEndDt", (Date) context.getValue("plannedEndDt"), psession)
                    test.setDueDt((Date) context.getValue("plannedEndDt"))
                    // gchinsky 03-07-2015: set control owner userid to x_ctrl_owner in testPlan
                    if (owner != null)
                        test.setCustStringFieldValue("x_ctrl_owner", owner.userId, psession)
                }
                final String initialSaveReason = ApplicationProperties.getInitialSaveReasonTxt(psession.getLocale());
                for (TestPlan testPlan : tests) {
                    testPlan.save(initialSaveReason, psession)
                }
            }
            psession.commit()
        }
    }

    private TestDefinitionEx getLatestTestDefinition(ControlInstance control) {
        if (!control.hasReferencesInTestDefinition(psession))
            return null
        BusinessObjectList<TestDefinitionEx> testDefns = control.getTestDefinitions(psession)
        TestDefinitionEx result = null
        Timestamp min = null
        for (TestDefinitionEx testDefinition : testDefns) {
            if (testDefinition.getIsActive() && testDefinition.getIsFullyValidated()) {
                Timestamp temp = testDefinition.getCreatedOnDttm()
                if (min == null) {
                    min = temp
                    result = testDefinition
                } else {
                    if (min < temp) {
                        min = temp
                        result = testDefinition
                    }
                }
            }
        }
        return result
    }

    private boolean isLocationContainsNode(DimensionalArea location, Collection<DimensionNode> nodes) {
        for (DimensionNode dimensionNode : nodes)
            if (location.containsNode(dimensionNode, psession))
                return true
        return false
    }

    private Set<DimensionNode> getDimensionNodesByDimension(Collection<DimensionNode> dimensionalPoints, Dimension dimension) {
        Set<DimensionNode> targetDimensionalPoints = new HashSet<DimensionNode>()
        for (DimensionNode node : dimensionalPoints) {
            if (node.getDimension() == dimension)
                targetDimensionalPoints.add(node)
        }
        return targetDimensionalPoints
    }

    private void createLinksAuditToCo3(String linkTypeSourceSystemCd, String linkTypeId, Audit audit, LinkInstanceContainer container) {
        CreateLinkInstance creator = new CreateLinkInstance()
        for (CustomObject3 co3 : finIndicatorsToLink) {
            creator.evaluate(linkTypeSourceSystemCd, linkTypeId, audit, co3.getTaggedPointerHandle().toString(), container)
        }
    }

    private void linkControls(Audit audit) {
        for (ControlInstance controlInstance : controlsToLink)
            audit.addToTestExecutionContexts(controlInstance, psession)
    }

    private boolean isLboContainerForLinkTypeEmpty(LinkType linkType, LinkInstanceContainer container) {
        if (linkType == null)
            return false
        Map<Long, LinkInstance> existingLinks = container.getLinkInstanceMap(linkType.getLinkTypeRk())
        if (existingLinks.size() > 0)
            return false
        return true
    }

    private boolean isAuditTestsEmpty(Audit audit) {
        List<TestPlan> tests = audit.getAllCachedTests()
        return tests.size() == 0
    }

    private boolean isAuditControlsEmpty(Audit audit) {
        if (audit.getControls(psession).size() > 0)
            return false
        return true
    }
}

package customfunctions

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.monitor.web.AppRequestContext
import com.sas.oprisk.monitor.web.AppRequestContextHolder
import com.sas.oprisk.monitor.web.MonitorSession
import com.sas.oprisk.server.ControlInstance
import com.sas.oprisk.server.CustomObject2
import com.sas.oprisk.server.LinkInstance
import com.sas.oprisk.server.LinkType
import com.sas.oprisk.server.behavior.PrimaryBusinessObject
import com.sas.oprisk.server.cpb.expr.function.CreateLinkInstance
import com.sas.oprisk.server.logical.LinkInstanceContainer
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.oprisk.server.web.cpb.runtime.MonitorUIContext
import com.sas.solutions.cpb.docs.*
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

/**
 * Created by Nikolay Litvyak (SAS Russia) on 31.03.2016.
 */
@FunctionDescription("Функция для автоматического линкования связанных контрольных процедур.")
@FunctionReturnType("Boolean")
@FunctionReturnDescription("True - если функция отработала успешно, False - если нет.")
@FunctionArguments([
        @FunctionArgument(name = "businessObject", type = "PrimaryBusinessObject", description = "Предложение к которому необходимо прилинковать контрольную процедуру"),
        @FunctionArgument(name = "container", type = "LinkInstanceContainer", description = "Ссылка на контейнер экземпляров связи (LinkInstance)"),
        @FunctionArgument(name = "linkTypeId", type = "String", description = "Идентификатор типа связи"),
        @FunctionArgument(name = "sourceSystemCd", type = "String", description = "Исходная система")
])
@FunctionExamples([
        @FunctionExample(code = "<set name=\"TEMP.C_LinkAssociatedControls\" value=\"C_LinkAssociatedControls(businessObject,linkedBusinessObjects,'x_co2_x_control','MON')\"/>"),
])
class LinkAssociatedControls extends Function {

    private static Log log = LogFactory.getLog(LinkAssociatedControls.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {

        CustomObject2 customObject2 = (CustomObject2) args[0]
        LinkInstanceContainer container = (LinkInstanceContainer) args[1]
        String x_co2_x_control = (String) args[2]
        String sourceSystemCd = args[3]

        PersistenceSession psession = ServiceLocator.getPersistenceSession()

        AppRequestContext appCtx = AppRequestContextHolder.getRequestContext()
        MonitorSession msession = appCtx.getSessionContext()
        MonitorUIContext srcCtx = msession.getCachedContext("TestPlan")

        if (srcCtx == null)
            return false
        ControlInstance control = (ControlInstance) srcCtx.getValue("CONTROL")
        if (control == null)
            return false
        if (isContainerValid(sourceSystemCd, x_co2_x_control, container, psession))
            createLinks(sourceSystemCd, x_co2_x_control, customObject2, control, container)
        return true
    }

    @Override
    int getArgumentCount() {
        return 0
    }

    private void createLinks(String linkTypeSourceSystemCd, String linkTypeId, PrimaryBusinessObject hostBusinessObject, PrimaryBusinessObject object, LinkInstanceContainer container) {
        CreateLinkInstance creator = new CreateLinkInstance()
        creator.evaluate(linkTypeSourceSystemCd, linkTypeId, hostBusinessObject, object.getTaggedPointerHandle().toString(), container)
    }

    private boolean isContainerValid(String linkTypeSourceSystemCd, String linkTypeId, LinkInstanceContainer container, PersistenceSession psession) {
        LinkType linkType = LinkType.object.fetchIfExistsByExternalReference(linkTypeSourceSystemCd, linkTypeId, psession)
        if (linkType == null)
            return false
        Map<Long, LinkInstance> existingLinks = container.getLinkInstanceMap(linkType.getLinkTypeRk())
        if (existingLinks.size() > 0)
            return false
        return true
    }
}

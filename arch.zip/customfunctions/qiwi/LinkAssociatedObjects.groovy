package customfunctions

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.Audit
import com.sas.oprisk.server.ControlInstance
import com.sas.oprisk.server.CustomObject3
import com.sas.oprisk.server.DimensionNode
import com.sas.oprisk.server.LinkInstance
import com.sas.oprisk.server.LinkType
import com.sas.oprisk.server.cpb.expr.function.CreateLinkInstance
import com.sas.oprisk.server.logical.DimensionalArea
import com.sas.oprisk.server.logical.DimensionalAreaHandle
import com.sas.oprisk.server.logical.LinkInstanceContainer
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
import com.sas.solutions.cpb.docs.*

/**
 * Created by Nikolay Litvyak (SAS Russia) on 11.02.2016.
 */

@FunctionDescription("Create audit scope based on location of 'Audit mission' ")
@FunctionReturnType("Boolean")
@FunctionReturnDescription("True if evaluation was successful.")
@FunctionArguments([
        @FunctionArgument(name = "Audit", type = "Audit", description = "Audit for scope creation"),
        @FunctionArgument(name = "location", type = "DimensionalAreaHandle", description = "Dimensional Area (location field)"),
        @FunctionArgument(name = "container", type = "LinkInstanceContainer", description = "LinkInstanceContainer object"),
])
@FunctionExamples([
        @FunctionExample(code = "<set name=\"TEMP.link\" value=\"C_LinkAssociatedObjects(businessObject,location,linkedBusinessObjects)\"/>")
])

class LinkAssociatedObjects extends Function {
    private static Log log = LogFactory.getLog(LinkAssociatedObjects.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        LinkAssociatedObjectsImpl function = new LinkAssociatedObjectsImpl()
        return function.evaluate(args);
    }

    @Override
    int getArgumentCount() {
        return 3
    }
}

class LinkAssociatedObjectsImpl{

    private final String linkCo3ToAuditName = "FIN_AUDIT_CO3"
    private final String linkCo3ToControlsName = "CNTRL_FIN_CO3"
    private final String SourceSystemCd = "MON"
    LinkType linkCo3ToAudit
    LinkType linkCo3ToControls
    Set<ControlInstance> controlsToLink
    Set<CustomObject3> finIndicatorsToLink
    PersistenceSession psession

    private void init() {
        psession = ServiceLocator.getPersistenceSession()
        linkCo3ToAudit = LinkType.object.fetchByExternalReference(SourceSystemCd, linkCo3ToAuditName, psession)
        linkCo3ToControls = LinkType.object.fetchByExternalReference(SourceSystemCd, linkCo3ToControlsName, psession)
        controlsToLink = new HashSet<ControlInstance>()
        finIndicatorsToLink = new HashSet<CustomObject3>()
    }

    Object evaluate(Object[] args) throws EvaluationException {
        Audit audit = (Audit) args[0]
        DimensionalAreaHandle location = (DimensionalAreaHandle) args[1]
        LinkInstanceContainer container = (LinkInstanceContainer) args[2]
        if (location == null || audit == null || container == null)
            return false
        init()

        if (!(isLboContainerForLinkTypeEmpty(linkCo3ToAudit, container) && isAuditControlsEmpty(audit)))
            return false
        List<DimensionNode> dimensionalNodes = location.fetch(psession).getNodes(psession).toList()
        List<DimensionNode> manOrgNodes = getDimensionNodesByDimension(dimensionalNodes, "MANAGEMENT_ORG")
        List<DimensionNode> periodsNodes = getDimensionNodesByDimension(dimensionalNodes, "AUX_RPT_DIM_1")
        List<DimensionNode> itSystemsNodes = getDimensionNodesByDimension(dimensionalNodes, "PROJECT")

        List<CustomObject3> allFinIndicators = CustomObject3.ALL.execute(psession)
        for (CustomObject3 finIndicator : allFinIndicators) {
            if (!Boolean.TRUE.equals(finIndicator.getCustBooleanFieldValue("x_prizn", psession)))
                continue
            DimensionalArea finIndicatorLocation = finIndicator.getLocation(psession)
            boolean containsManOrg = isLocationContainsNode(finIndicatorLocation, manOrgNodes)
            boolean containsPeriods = isLocationContainsNode(finIndicatorLocation, periodsNodes)
            if (containsManOrg && containsPeriods)
                finIndicatorsToLink.add(finIndicator)
        }

        List<ControlInstance> allControls = ControlInstance.ALL.execute(psession)
        for (ControlInstance control : allControls) {
            DimensionalArea controlLocation = control.getLocation(psession)
            boolean containsManOrg = isLocationContainsNode(controlLocation, manOrgNodes)
            boolean containsItSystems = isLocationContainsNode(controlLocation, itSystemsNodes)
            if (containsManOrg && containsItSystems)
                controlsToLink.add(control)
        }

        createLinksAuditToCo3(SourceSystemCd, linkCo3ToAuditName, audit, container)
        populateControlsFromCo3(finIndicatorsToLink)
        linkControls(audit)
        return true
    }

    private boolean isLocationContainsNode(DimensionalArea location, List<DimensionNode> nodes) {
        boolean locationContainsNode = false;
        for (DimensionNode dimensionNode : nodes)
            if (location.containsNode(dimensionNode, psession))
                locationContainsNode = true
        return locationContainsNode
    }

    private List<DimensionNode> getDimensionNodesByDimension(List<DimensionNode> dimensionalPoints, String dimension) {
        List<DimensionNode> targetDimensionalPoints = new ArrayList<DimensionNode>()
        for (DimensionNode node : dimensionalPoints) {
            if (node.getDimension().getSqlName() == dimension)
                targetDimensionalPoints.add(node)
        }
        return targetDimensionalPoints
    }

    private void createLinksAuditToCo3(String linkTypeSourceSystemCd, String linkTypeId, Audit audit, LinkInstanceContainer container) {
        CreateLinkInstance creator = new CreateLinkInstance()
        for (CustomObject3 co3 : finIndicatorsToLink) {
            creator.evaluate(linkTypeSourceSystemCd, linkTypeId, co3, audit.getTaggedPointerHandle().toString(), container)
        }
    }

    private void populateControlsFromCo3(Set<CustomObject3> finIndicators) {
        for (CustomObject3 finIndicator : finIndicators) {
            Set<LinkInstance> linksToControls = finIndicator.getLinkInstancesForLinkType(linkCo3ToControls.getLinkTypeRk(), psession)
            for (LinkInstance linkToControl : linksToControls) {
                controlsToLink.add(ControlInstance.object.fetch(linkToControl.getBusinessObjectRk1(), psession))
            }
        }
    }

    private void linkControls(Audit audit) {
        for (ControlInstance controlInstance : controlsToLink)
            audit.addToTestExecutionContexts(controlInstance, psession)
    }

    private boolean isLboContainerForLinkTypeEmpty(LinkType linkType, LinkInstanceContainer container) {
        if (linkType == null)
            return false
        Map<Long, LinkInstance> existingLinks = container.getLinkInstanceMap(linkType.getLinkTypeRk())
        if (existingLinks.size() > 0)
            return false
        return true
    }

    private boolean isAuditControlsEmpty(Audit audit) {
        if (audit.getControls(psession).size() > 0)
            return false
        return true
    }
}
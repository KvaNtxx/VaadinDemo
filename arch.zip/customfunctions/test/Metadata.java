package customfunctions.test;

import com.sas.metadata.remote.*;

import java.rmi.RemoteException;
import java.util.*;

/**
 * Created by Nikolay Litvyak (SAS Russia) on 05.07.2016.
 */
public class Metadata {
    public static void main(String[] args) {
        MdTesterExamples meta = new MdTesterExamples();
        meta.connectToServer();
        MdFactory factory = meta._factory;
        MdObjectStore objectStore = null;
        meta.readTable(meta.getAllRepositories().get(0));
    }
}

class MdTesterExamples {
    /**
     * The object factory instance.
     */
    public MdFactory _factory = null;

    /**
     * Default constructor
     */
    public MdTesterExamples() {
        // Calls the factory's constructor
        initializeFactory();
    }

    private void initializeFactory() {
        try {
            // Initializes the factory.  The boolean parameter is used to
            // determine if the application is running in a remote or local environment.
            // If the data does not need to be accessible across remote JVMs,
            // then "false" can be used, as shown here.
            _factory = new MdFactoryImpl(false);

            // Defines debug logging, but does not turn it on.
            boolean debug = false;
            if (debug) {
                _factory.setDebug(false);
                _factory.setLoggingEnabled(false);

                // Sets the output streams for logging.  The logging output can be
                // directed to any OutputStream, including a file.
                _factory.getUtil().setOutputStream(System.out);
                _factory.getUtil().setLogStream(System.out);
            }

            // To be notified of changes that have been persisted to the SAS Metadata
            // Server within this factory (this includes adding objects, updating
            // objects, and deleting objects), we can add a listener to the factory
            // here. See MdFactory.addMdFactoryListener().
            // A listener is not needed for this example.
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * The following statements define variables for SAS Metadata Server
     * connection properties, instantiate a connection factory, issue
     * the makeOMRConnection method, and check exceptions for error conditions.
     */
    public boolean connectToServer() {
        String serverName = "sasbap.demo.sas.com";
        String serverPort = "8561";
        String serverUser = "sasadm@saspw";
        String serverPass = "Orion123";


        try {
            MdOMRConnection connection = _factory.getConnection();

            // This statement makes the connection to the server.
            connection.makeOMRConnection(serverName, serverPort, serverUser, serverPass);

            // The following statements define error handling and error
            // reporting messages.
        } catch (MdException e) {
            Throwable t = e.getCause();
            if (t != null) {
                String ErrorType = e.getSASMessageSeverity();
                String ErrorMsg = e.getSASMessage();
                if (ErrorType == null) {
                    // If there is no SAS server message, write a Java/CORBA message.
                } else {
                    // If there is a message from the server:
                    System.out.println(ErrorType + ": " + ErrorMsg);
                }
                if (t instanceof org.omg.CORBA.COMM_FAILURE) {
                    // If there is an invalid port number or host name:
                    System.out.println(e.getLocalizedMessage());
                } else if (t instanceof org.omg.CORBA.NO_PERMISSION) {
                    // If there is an invalid user ID or password:
                    System.out.println(e.getLocalizedMessage());
                }
            } else {
                // If we cannot find a nested exception, get message and print.
                System.out.println(e.getLocalizedMessage());
            }
            // If there is an error, print the entire stack trace.
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            // Unknown exception.
            e.printStackTrace();
            return false;
        }
        // If no errors occur, then a connection is made.
        return true;
    }

    public List<CMetadata> getAllRepositories() {
        try {
            System.out.println("\nThe repositories contained on this SAS Metadata " +
                    "Server are:");

            // The getRepositories method lists all repositories.
            MdOMIUtil omiUtil = _factory.getOMIUtil();
            List<CMetadata> reposList = omiUtil.getRepositories();
            for (CMetadata repository : reposList) {
                // Print the name and id of each repository.
                System.out.println("Repository: " +
                        repository.getName()
                        + " (" + repository.getFQID() + ")");
            }
            return reposList;
        } catch (MdException e) {
            e.printStackTrace();
        } catch (java.rmi.RemoteException e) {
            e.printStackTrace();
        }
        return Collections.emptyList();
    }

    public void readTable(CMetadata repository)
    {
        if(repository != null)
        {
            try
            {
                System.out.println("\nReading objects from the server...");

                // First we create an MdObjectStore as a container for the
                // objects that we will create/read/persist to the server as
                // one collection.
                MdObjectStore store = _factory.createObjectStore();

                // The following statements define variables used within the
                // getMetadataObjectsSubset method.These XML strings are used in conjunction
                // with SAS Open Metadata Interface flags. The <XMLSELECT> element
                // specifies filter criteria. The objects returned are filtered by the
                // PublicType and Name values. The <TEMPLATES> element specifies the
                // associations to be expanded for each object.

                String xmlSelect = "<XMLSELECT Search=\"*[@PublicType='Table' and " +
                        "@Name='TableTest']\"/>";
                String template =
                        "<Templates>" +
                                "<PhysicalTable>" +
                                "<Columns/>" +
                                "</PhysicalTable>" +
                                "<Column>" +
                                "<Keywords/>" +
                                "</Column>" +
                                "</Templates>";

                // Add the XMLSELECT and TEMPLATES strings together.
                String sOptions = xmlSelect + template;

                // The following statements go to the server with a fully-qualified
                // repository ID and specify the type of object we are searching for
                // (MetadataObjects.PHYSICALTABLE) using the OMI_XMLSELECT, OMI_TEMPLATE,
                // OMI_ALL_SIMPLE, and OMI_GET_METADATA flags. OMI_ALL_SIMPLE specifies
                // to get all simple attributes for all objects that are returned.
                // OMI_GET_METADATA activates the GetMetadata flags in the GetMetadataObjects
                // request.
                //
                // The table, column, and keyword will be read from the server and created
                // within the specified object store.
                int flags = MdOMIUtil.OMI_XMLSELECT | MdOMIUtil.OMI_TEMPLATE |
                        MdOMIUtil.OMI_ALL_SIMPLE | MdOMIUtil.OMI_GET_METADATA;
                List tableList = _factory.getOMIUtil().getMetadataObjectsSubset(store,
                        repository.getFQID(),
                        MetadataObjects.PHYSICALTABLE,
                        flags,
                        sOptions);
                Iterator iter = tableList.iterator();
                while (iter.hasNext())
                {
                    // Print the Name, Id, PublicType, UsageVersion, and ObjPath values
                    // of the table returned from the server. ObjPath is the folder location.
                    PhysicalTable table = (PhysicalTable) iter.next();
                    System.out.println("Found table: " + table.getName() + " (" +
                            table.getId() + ")");

                    System.out.println("\tType: " + table.getPublicType());
                    System.out.println("\tUsage Version: " + table.getUsageVersion());
                    System.out.println("\tPath: " + _factory.getOMIUtil().getObjectPath(store,
                            table, false));

                    // Get the list of columns for this table.
                    AssociationList columns = table.getColumns();
                    for (int i = 0; i < columns.size(); i++)
                    {
                        // Print the Name, Id, PublicType, UsageVersion, Desc, and ColumnName
                        // values for each column associated with the table.
                        Column column = (Column) columns.get(i);
                        System.out.println("Found column: " + column.getName() + " (" +
                                column.getId() + ")");

                        System.out.println("\tType: " + column.getPublicType());
                        System.out.println("\tUsage Version: " + column.getUsageVersion());
                        System.out.println("\tDescription: " + column.getDesc());
                        System.out.println("\tColumnName: " + column.getColumnName());

                        // Get the list of keywords associated with the columns.
                        AssociationList keywords = column.getKeywords();
                        for (int j = 0; j < keywords.size(); j++)
                        {
                            // Print the Name and Id values of each keyword associated with
                            // the column.
                            Keyword keyword = (Keyword) keywords.get(j);
                            System.out.println("Found keyword: " + keyword.getName() + " (" +
                                    keyword.getId() + ")");
                        }
                    }
                }

                // When finished, clean up the objects in the store if they
                // are no longer being used.
                store.dispose();
            }
            catch (MdException e)
            {
                e.printStackTrace();
            }
            catch (RemoteException e)
            {
                e.printStackTrace();
            }
        }
    }
}

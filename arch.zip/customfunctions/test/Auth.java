package customfunctions.test;

import com.google.common.io.CharStreams;
import com.sas.svcs.security.authentication.client.AuthenticationClient;
import com.sas.svcs.security.authentication.client.AuthenticationClientHolder;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;

import java.io.*;
import java.net.URL;
import java.util.Scanner;

/**
 * Created by Nikolay Litvyak (SAS Russia) on 28.06.2016.
 */
public class Auth {
    public static void main(String[] args) throws IOException {
        System.out.println("dd");
        String casUrl = "http://sasbap.demo.sas.com/SASLogon";
        AuthenticationClient client = new AuthenticationClient(casUrl);
        client.logon("grcadmin", "Orion123");
        AuthenticationClientHolder.set(client);


        AuthenticationClient authClient = AuthenticationClientHolder.get();
        String someServiceURL = "http://sasbap.demo.sas.com/SASEnterpriseGRC/customfunctions/Echo2.groovy";
        String ticket = authClient.acquireTicket(someServiceURL);

        HttpClient httpClient = new HttpClient();
        GetMethod get = new GetMethod("http://sasbap.demo.sas.com/SASEnterpriseGRC/customfunctions/Echo2.groovy?ticket=" + ticket);
        int statusCode = httpClient.executeMethod(get);

        if (statusCode != HttpStatus.SC_OK) {
            System.err.println("Method failed: " + get.getStatusLine());
        }

        // Read the response body.
        byte[] responseBody = get.getResponseBody();

        // Deal with the response.
        // Use caution: ensure correct character encoding and is not binary data
        System.out.println(new String(responseBody));


        get.releaseConnection();

    }
}

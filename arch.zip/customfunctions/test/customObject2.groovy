package customfunctions.test

import com.sas.oprisk.framework.server.dataload.xls.XlsEntry
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.services.ServiceLocator
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
import org.apache.poi.ss.usermodel.Row;

/**
 * Created by Nikolay Litvyak (SAS Russia) on 18.07.2016.
 */

def validate(Object entry) {
    if (entry instanceof XlsEntry) {
        Row row = entry.row
        Log log = LogFactory.getLog(this.class)
        log.warn("DEBUG!!!!!!!!!!!!!!!!!!!!!" + entry)
        String legalImpact = entry.getValue("customObject2.custObj2Id")
        PersistenceSession psession = ServiceLocator.getPersistenceSession();
        log.warn(psession.getUser())
    }
    return "";
}
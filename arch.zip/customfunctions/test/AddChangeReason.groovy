package customfunctions

import com.sas.oprisk.framework.server.OpRiskFrameworkError
import com.sas.oprisk.framework.server.objects.AbstractChangeReason
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.ChangeReason
import com.sas.oprisk.server.CustomObject1
import com.sas.oprisk.server.CustomObject5
import com.sas.oprisk.server.OpRiskEvent
import com.sas.oprisk.server.User
import com.sas.oprisk.server.behavior.ChangeReasonImpl
import com.sas.oprisk.server.behavior.PrimaryBusinessObject
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException

import java.sql.Timestamp

/**
 * Created by Nikolay Litvyak (SAS Russia) on 15.08.2016.
 */
class AddChangeReason extends Function{


    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        CustomObject5 co5 = args[0] as CustomObject5;
        String value = args[1]
        PersistenceSession psession = ServiceLocator.getPersistenceSession()


        ChangeReason r = ChangeReason.object.create(psession);
        r.setSubject(co5);
        r.setSaveDttm(co5.getCreatedDttm());
        r.setReasonTxt(value);

        try {
            r.setEditor((User)psession.getUser());
        } catch (ClassCastException var11) {
            throw new OpRiskFrameworkError("Wrong type of user.", var11);
        }

        r.save(psession);
        co5.save(null as AbstractChangeReason,null)
        return true

    }

    @Override
    int getArgumentCount() {
        return 0
    }
}

package customfunctions.test

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.Incident
import com.sas.oprisk.server.OpRiskEvent
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

/**
 * Created by Nikolay Litvyak (SAS Russia) on 21.06.2016.
 */
class ThreadTest extends Function {

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        Thread th = new Thread(new BackgroundExecutioner(psession))
        th.start()
        return null
    }

    @Override
    int getArgumentCount() {
        return 0
    }
}

class BackgroundExecutioner implements Runnable {
    private static Log log = LogFactory.getLog(BackgroundExecutioner.class)
    PersistenceSession psession

    BackgroundExecutioner(PersistenceSession psession) {
        this.psession = psession
    }

    @Override
    void run() {
        try {
            /*
        log.warn("my first time)))")
        for (int i = 0; i < 20; i++) {

                PersistenceSession session
                log.warn("IT'S ME!!!" + i + "   " + psession.getUser())
                Thread.sleep(3000)
            } catch (Exception e) {
                log.warn(e)
            }
        }*/
            log.warn("1");
            List<OpRiskEvent> incidents = OpRiskEvent.ALL.execute(psession);
            Thread.sleep(30000)
            log.warn("2");
            log.warn(incidents);
        } catch (Exception e) {
            log.warn(e)
        }
    }

}
package customfunctions.test

import com.sas.metadata.remote.MdFactory
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.framework.server.persistence.SqlPersistenceSession
import com.sas.oprisk.server.Position
import com.sas.oprisk.server.Role
import com.sas.oprisk.server.User
import com.sas.oprisk.server.behavior.SudoPersistenceSessionWrapper
import com.sas.oprisk.server.logical.DimensionalArea
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import com.sas.workspace.Workspace
import customfunctions.ClearInvalidLinkInstances
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

/**
 * Created by Nikolay Litvyak (SAS Russia) on 09.06.2016.
 */
class RoleTests extends Function {
    private static Log log = LogFactory.getLog(ClearInvalidLinkInstances.class);

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        /*
    }
        User user = (User) args[0]
        PersistenceSession psession = new SudoPersistenceSessionWrapper(ServiceLocator.getPersistenceSession())
        log.warn("CF DEBUG: ------------------------------------------------\n")
        Position pos = user.assignRole(Role.object.fetchByName("Enterprise GRC: Administration", psession), DimensionalArea.object.getTop(psession), psession)
        pos.save("auto",psession)
        List<Position> positions = user.getPositions(psession)
        for (Position position : positions) {
            log.warn(position.getRole(psession).toString() + "   " + position.getLocation(psession).isTop(psession))
        }
        user.save("auto",psession)
        psession.commit()
        log.warn("CF DEBUG END: ------------------------------------------------ ")*/
        MdFactory factory = Workspace.getMdFactory();
        log.warn("DBUG zzzzzzzzzzzzzzzzzzzzzzzzzzz" + factory.toString())
        return null
    }

    @Override
    int getArgumentCount() {
        return 0
    }
}

package customfunctions

import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.monitor.web.dataload.DataLoadWebDriver
import com.sas.oprisk.monitor.web.dataload.LoaderResults
import com.sas.oprisk.monitor.web.dataload.UploadLogger
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.docs.FunctionArgument
import com.sas.solutions.cpb.docs.FunctionArguments
import com.sas.solutions.cpb.docs.FunctionDescription
import com.sas.solutions.cpb.docs.FunctionExample
import com.sas.solutions.cpb.docs.FunctionExamples
import com.sas.solutions.cpb.docs.FunctionReturnDescription
import com.sas.solutions.cpb.docs.FunctionReturnType
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
import org.apache.poi.ss.usermodel.Workbook
import org.apache.poi.ss.usermodel.WorkbookFactory

/**
 * Created by Nikolay Litvyak (SAS Russia) on 25.03.2016.
 */

@FunctionDescription("Upload Excel loader from specified server folder")
@FunctionReturnType("String")
@FunctionReturnDescription("Upload report")
@FunctionArguments([
        @FunctionArgument(name = "path", type = "String", description = "Path to server folder. After loading within this folder created Excel report file."),
        @FunctionArgument(name = "fileName", type = "String", description = "Filename of Excel loader "),
])
@FunctionExamples([
        @FunctionExample(code = "<set name=\"TEMP.upload\" value=\"c_UploadFile('C:/Data/','load.xls')\"/>")
])
class UploadFile extends Function {

    private static Log log = LogFactory.getLog(UploadFile.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        String dir = (String) args[0]
        String fileName = (String) args[1]

        DataLoadWebDriver driver = new DataLoadWebDriver()
        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        try {
            File filePath = new File(dir + fileName)
            FileInputStream file = new FileInputStream(filePath);
            Workbook wb = WorkbookFactory.create(file);
            UploadLogger logger = driver.loadSpreadSheet(wb, false, true, true, false, psession, Locale.getDefault())
            file.close()

            Workbook report = logger.getWorkbook()
            FileOutputStream fileOut = new FileOutputStream(dir + fileName + " - report.xls", false);
            report.write(fileOut);
            fileOut.close();

            return getStatistics(logger.getResults())
        } catch (Exception e) {
            return e.toString()
        }
    }

    @Override
    int getArgumentCount() {
        return 0
    }

    String getStatistics(LoaderResults[] loaderResultses) {
        String result = ""
        if (loaderResultses.length > 0 && loaderResultses[0].changesCommitted) {
            result += "Added: " + getSuccesses(loaderResultses) + "\n"
            result += "No Change: " + getUnchanged(loaderResultses) + "\n"
        } else {
            result = "Invalid loader"
        }
        return result
    }

    int getSuccesses(LoaderResults[] loaderResultses) {
        int count = 0;
        for (LoaderResults loaderResults : loaderResultses) {
            count += loaderResults.successes
        }
        return count
    }

    int getUnchanged(LoaderResults[] loaderResultses) {
        int count = 0;
        for (LoaderResults loaderResults : loaderResultses) {
            count += loaderResults.unchanged
        }
        return count
    }

    int getErrors(LoaderResults[] loaderResultses) {
        int count = 0;
        for (LoaderResults loaderResults : loaderResultses) {
            count += loaderResults.errors
        }
        return count
    }
}

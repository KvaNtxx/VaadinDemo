package customfunctions

import com.sas.oprisk.framework.server.persistence.DatabaseConnectionProvider
import com.sas.oprisk.framework.server.persistence.SqlPersistenceSession
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

import java.lang.reflect.Field
import java.sql.Connection
import java.sql.SQLException
import java.sql.Statement
/**
 * Created by rusnli on 01.03.2016.
 */
class GetPassword extends Function{

    private static Log log = LogFactory.getLog(GetPassword.class)

    @Override
    Object evaluate(Object[] objects) throws EvaluationException {

        SqlPersistenceSession psession =(SqlPersistenceSession) ServiceLocator.getPersistenceSession()
        Field f = psession.getClass().getDeclaredField("connectionProvider"); //NoSuchFieldException
        f.setAccessible(true);
        DatabaseConnectionProvider connectionProvider = (DatabaseConnectionProvider) f.get(psession)
        Connection conn = connectionProvider.openConnection()
        Statement stmt = conn.createStatement();
        log.warn("DEBUG "+ conn.isClosed() )
            String createTableSQL = "CREATE TABLE AAA_DBUSER( USER_ID NUMBER(5) NOT NULL, USERNAME VARCHAR(20) NOT NULL,CREATED_BY VARCHAR(20) NOT NULL, CREATED_DATE DATE NOT NULL, " + "PRIMARY KEY (USER_ID) )"
        try {
            stmt.execute(createTableSQL)
        }catch(SQLException e)
        {
            log.warn(e)
        }
        finally {
            connectionProvider.closeConnection(conn)
        }

        return null
    }

    @Override
    int getArgumentCount() {
        return 0
    }
}

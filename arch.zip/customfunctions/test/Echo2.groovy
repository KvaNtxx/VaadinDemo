package customfunctions

import com.sas.oprisk.server.ControlInstance
import com.sas.oprisk.server.FinancialImpact
import com.sas.oprisk.server.User;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

My my = new My()
my.eval(binding)

class My {
    private static Log log = LogFactory.getLog(My.class);

    public Object eval(Binding binding) {
        HttpServletResponse response = (HttpServletResponse) binding.getVariable("response")
        PrintWriter out = response.getWriter();
        out.print("<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">\n" +
                "        <html>\n" +
                "        <head>\n" +
                "        <title>406 Not Found</title>\n" +
                "</head>\n" +
                "        <body>\n" +
                "        <h1>Not Found</h1>\n" +
                "   <p>" + binding.getVariables() + "</p>\n" +
                "</body>\n" +
                "        </html>")
ControlInstance c = null;
        FinancialImpact impact = null;
        log.warn(binding.getVariables())
        return "YEAHHHHHHHHHH!!!!!!!!!!!"
    }

    public static String getBody(HttpServletRequest request) throws IOException {

        String body = null;
        StringBuilder stringBuilder = new StringBuilder();
        BufferedReader bufferedReader = null;

        try {
            InputStream inputStream = request.getInputStream();
            if (inputStream != null) {
                bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                char[] charBuffer = new char[128];
                int bytesRead = -1;
                while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
                    stringBuilder.append(charBuffer, 0, bytesRead);
                }
            } else {
                stringBuilder.append("");
            }
        } catch (IOException ex) {
            throw ex;
        } finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException ex) {
                    throw ex;
                }
            }
        }

        body = stringBuilder.toString();
        return body;
    }
}
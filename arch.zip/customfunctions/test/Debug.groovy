package customfunctions

import com.sas.oprisk.framework.server.OpRiskException
import com.sas.oprisk.framework.server.objects.BusinessObjectList
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.monitor.web.AppRequestContext
import com.sas.oprisk.monitor.web.AppRequestContextHolder
import com.sas.oprisk.monitor.web.incident.IncidentModel
import com.sas.oprisk.server.FinancialImpact
import com.sas.oprisk.server.ImpactDetail
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.oprisk.server.web.cpb.runtime.MonitorUIContext
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import com.sas.solutions.cpb.runtime.UIContext
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

/**
 * Created by Nikolay Litvyak (SAS Russia) on 12.05.2016.
 */
class Debug extends Function{
    private static Log log = LogFactory.getLog(Debug.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        log.warn("\n\n\n" + "||----------------------------------S T A R T   D E B U G-----------------------------------||")
        PersistenceSession psession = ServiceLocator.getPersistenceSession();
        final AppRequestContext appCtx = AppRequestContextHolder.getRequestContext();
        UIContext context = getContext();

        log.warn(context.toString())

        log.warn("\n\n\n" + "||----------------------------------E N D   D E B U G---------------------------------------||" + "\n\n\n")
        return null
    }


    @Override
    int getArgumentCount() {
        return 0
    }
}

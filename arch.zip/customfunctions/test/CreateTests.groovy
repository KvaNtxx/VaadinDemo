package customfunctions.test

import com.sas.oprisk.framework.server.objects.BusinessObjectList
import com.sas.oprisk.framework.server.persistence.PersistenceSession
import com.sas.oprisk.server.*
import com.sas.oprisk.server.services.ServiceLocator
import com.sas.solutions.cpb.expr.function.Function
import com.sas.solutions.cpb.runtime.EvaluationException
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
/**
 * Created by Nikolay Litvyak (SAS Russia) on 21.04.2016.
 */
class CreateTests extends Function{
    private static Log log = LogFactory.getLog(CreateTests.class)

    @Override
    Object evaluate(Object[] args) throws EvaluationException {
        PersistenceSession psession = ServiceLocator.getPersistenceSession()
        Audit audit = (Audit) args[0]
        BusinessObjectList<ControlInstance> controls = audit.getControls(psession)
        for(ControlInstance ci: controls)
        {
            boolean hasTestDef = ci.getTestDefinitions(psession)
            if(hasTestDef)
            {
                BusinessObjectList<TestDefinitionEx> testDefinitions = ci.getTestDefinitions(psession)
                String handle = testDefinitions.get(0).getTaggedPointerHandle()
                Object[] temp = audit.createNewTestPlans(ci.getHandle().toString(), [handle] as String[],psession)
                BusinessObjectList<TestPlan> tests = temp[0]
                final String initialSaveReason = ApplicationProperties.getInitialSaveReasonTxt(psession.getLocale());
                tests.get(0).save(initialSaveReason,psession)
            }
            psession.commit()
        }
        return null
    }

    @Override
    int getArgumentCount() {
        return 0
    }
}

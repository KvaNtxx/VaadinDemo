package customfunctions;

import com.sun.prism.shader.Solid_TextureYV12_AlphaTest_Loader;

/**
 * Created by Nikolay Litvyak (SAS Russia) on 01.08.2016.
 */
public class qqq {
    public static void main(String[] args) throws InterruptedException {
        Runnable runnable = new Runnable() {

            @Override
            public void run() {
                int i = 0;
                for (; ; ) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    i++;
                    System.out.println(i);
                }
            }
        };

        Thread thread = new Thread(runnable);
        thread.setDaemon(true);
        thread.start();

        Thread.sleep(5000);
        System.out.println("I am up");
        return;
    }
}

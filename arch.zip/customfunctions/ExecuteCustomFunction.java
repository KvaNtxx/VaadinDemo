package customfunctions;

import com.sas.oprisk.framework.server.persistence.PersistenceSession;
import com.sas.oprisk.server.services.ServiceLocator;
import com.sas.solutions.cpb.expr.function.Function;
import com.sas.solutions.cpb.runtime.EvaluationException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import java.util.Arrays;

/**
 * Created by Nikolay Litvyak (SAS Russia) on 11.05.2016.
 */
public class ExecuteCustomFunction extends Function {
    private static Log log = LogFactory.getLog(ExecuteCustomFunction.class);
    static int count = 0;
    @Override
    public Object evaluate(Object[] args) throws EvaluationException {
        PersistenceSession psession = ServiceLocator.getPersistenceSession();
        final String funcName = (String) args[0];
        final Function function = Function.getCachedCustomFunction(funcName);
        log.warn("CF DEBUG FUNC: " + function + " " + count++);
        log.warn("CF DEBUG PARAM: " + Arrays.toString(args));

        if((function != null) && !(args[1]).equals("0"))
        {
            String async = (String) args[2];
            args = Arrays.copyOfRange(args,3,args.length);
            log.warn("CF DEBUG GROOVY: " + Arrays.toString(args));
            if(async.equals("async"))
            {
                final Object[] finalArgs = args;
                new Runnable() {
                    @Override
                    public void run() {
                        try {
                            function.evaluate(finalArgs);
                        } catch (EvaluationException e) {
                            e.printStackTrace();
                        }
                    }
                };
                return "async";
            }
            return function.evaluate(args);
        }
        return "No Function";
    }

    @Override
    public int getArgumentCount() {
        return -1;
    }
}
